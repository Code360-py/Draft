from flask import Flask, render_template, request, redirect, url_for, session, flash
import csv
import os
import hashlib
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'  # Change this in production

# CSV file configurations
USERS_FILE = 'users.csv'
USER_HEADERS = ['email', 'password', 'name']
EXPENSES_FILE = 'expenses.csv'
EXPENSE_HEADERS = ['id', 'date', 'amount', 'category', 'description', 'user_email']

def init_files():
    if not os.path.exists(USERS_FILE):
        with open(USERS_FILE, 'w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=USER_HEADERS)

    if not os.path.exists(EXPENSES_FILE):
        with open(EXPENSES_FILE, 'w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=EXPENSE_HEADERS)
            writer.writeheader()

init_files()

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

def email_exists(email):
    with open(USERS_FILE, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row['email'] == email:
                return True
    return False

def validate_user(email, password):
    with open(USERS_FILE, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row['email'] == email and row['password'] == hash_password(password):
                return row
    return None

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        
        user = validate_user(email, password)
        if user:
            session['user_email'] = user['email']
            session['user_name'] = user['name']
            session['is_logged'] = True
            flash('Login successful!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid email or password', 'danger')
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']
        confirm_password = request.form['confirm_password']
        
        if password != confirm_password:
            flash('Passwords do not match', 'danger')
        elif email_exists(email):
            flash('Email already registered', 'danger')
        else:
            with open(USERS_FILE, 'a', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=USER_HEADERS)
                writer.writerow({
                    'email': email,
                    'password': hash_password(password),
                    'name': name
                })
            flash('Registration successful! Please login', 'success')
            return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/dashboard')
def dashboard():
    if 'user_email' not in session:
        return redirect(url_for('login'))
    
    # Read and process expenses from CSV
    expenses = []
    with open(EXPENSES_FILE, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row['user_email'] == session['user_email']:
                try:
                    # Ensure amount is properly formatted
                    row['amount'] = float(row['amount']) if row['amount'] else 0.0
                    expenses.append(row)
                except (ValueError, TypeError) as e:
                    app.logger.error(f"Error processing expense amount: {e}")
                    continue
    return render_template('dashboard.html', expenses=expenses)

@app.route('/add_expense', methods=['GET', 'POST'])
def add_expense():
    if 'user_email' not in session:
        return redirect(url_for('login'))
        
    if request.method == 'POST':
        # Get form data
        amount = request.form['amount']
        category = request.form['category']
        description = request.form['description']
        
        # Write to CSV
        with open(EXPENSES_FILE, 'a', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=EXPENSE_HEADERS)
            writer.writerow({
                'date': datetime.now().strftime('%Y-%m-%d'),
                'amount': amount,
                'category': category,
                'description': description,
                'user_email': session['user_email']
            })
        flash('Expense added successfully!', 'success')
        return redirect(url_for('dashboard'))
    return render_template('add_expense.html')

@app.route('/statistics')
def statistics():
    if 'user_email' not in session:
        return redirect(url_for('login'))
        
    now = datetime.now()
    month = request.args.get('month', default=now.month, type=int)
    year = request.args.get('year', default=now.year, type=int)
    
    expenses = []
    daily_expenses = {}
    with open(EXPENSES_FILE, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row['user_email'] == session['user_email']:
                try:
                    expense_date = datetime.strptime(row['date'], '%Y-%m-%d')
                    if expense_date.month == month and expense_date.year == year:
                        row['amount'] = float(row['amount']) if row['amount'] else 0.0
                        expenses.append(row)
                        day = expense_date.day
                        daily_expenses[day] = daily_expenses.get(day, 0) + row['amount']
                except (ValueError, KeyError) as e:
                    app.logger.error(f"Error processing expense: {e}")
                    continue
    
    category_totals = {}
    for expense in expenses:
        category = expense['category']
        amount = expense['amount']
        category_totals[category] = category_totals.get(category, 0) + amount
    
    days_in_month = 31 if month in [1,3,5,7,8,10,12] else 30
    if month == 2:
        days_in_month = 29 if (year % 4 == 0 and year % 100 != 0) or (year % 400 == 0) else 28
    
    daily_labels = list(range(1, days_in_month+1))
    daily_amounts = [daily_expenses.get(day, 0) for day in daily_labels]
    
    return render_template('statistics.html',
                         expenses=expenses,
                         categories=list(category_totals.keys()),
                         amounts=list(category_totals.values()),
                         daily_labels=daily_labels,
                         daily_amounts=daily_amounts,
                         current_month=month,
                         current_year=year)

@app.route('/logout')
def logout():
    # Remove the user's session
    session.pop("is_logged", None)
    return redirect('/')

if __name__ == '__main__':
    app.run(debug=True)
