# cogs/moderator.py
import discord
from discord.ext import commands, tasks
from discord import app_commands
import json
import os
import re
from collections import defaultdict, deque
from datetime import datetime, timedelta

BASE_DIR = os.path.join(os.getcwd(), "data")
os.makedirs(BASE_DIR, exist_ok=True)
SETTINGS_FILE = os.path.join(BASE_DIR, "server_settings.json")
WARN_FILE = os.path.join(BASE_DIR, "mod_warnings.json")

# ------------------ Persistence ------------------
def load_json(path, default):
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return default
    return default

def save_json(path, data):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4)

server_settings = load_json(SETTINGS_FILE, {})
warnings_store = load_json(WARN_FILE, {})

# ------------------ In-memory runtime helpers ------------------
# message history for spam detection: guild_id -> user_id -> deque[timestamps]
recent_messages = defaultdict(lambda: defaultdict(lambda: deque(maxlen=20)))
# message cache for ghost-ping (store recent messages content & mentions)
message_cache = {}  # message_id -> {"author_id": ..., "mentions": [...], "content": ..., "channel_id": ...}
# join tracking for raid detection: guild_id -> deque[timestamps]
recent_joins = defaultdict(lambda: deque(maxlen=200))

# ------------------ Config defaults ------------------
DEFAULT_AUTOMOD = {
    "automod": False,
    "log_channel": None,
    "welcome": False,
    "leave": False,
    "nsfw": False,
    "spam_threshold": 5,       # messages in window
    "spam_window_seconds": 8,  # window for spam detection
    "raid_join_threshold": 8,  # joins within raid_window is considered raid
    "raid_window_seconds": 12
}

# ------------------ Utilities ------------------
def ensure_guild_config(guild_id: int):
    gid = str(guild_id)
    if gid not in server_settings:
        server_settings[gid] = DEFAULT_AUTOMOD.copy()
        save_json(SETTINGS_FILE, server_settings)
    return server_settings[gid]

def ensure_user_warns(guild_id: int, user_id: int):
    g = str(guild_id)
    u = str(user_id)
    if g not in warnings_store:
        warnings_store[g] = {}
    if u not in warnings_store[g]:
        warnings_store[g][u] = 0
    save_json(WARN_FILE, warnings_store)
    return warnings_store[g][u]

def is_protected(member: discord.Member):
    """Return True if member should not be punished (admins, manage_messages, bot owners)."""
    if member.guild is None:
        return True
    if member.guild.owner_id == member.id:
        return True
    perms = member.guild_permissions
    # protect administrators and moderators
    if perms.administrator or perms.manage_guild or perms.manage_messages:
        return True
    return False

def send_mod_log(guild: discord.Guild, embed: discord.Embed):
    cfg = server_settings.get(str(guild.id), {})
    log_id = cfg.get("log_channel")
    if not log_id:
        return
    ch = guild.get_channel(log_id)
    if not ch:
        return
    try:
        return ch.send(embed=embed)
    except Exception:
        return

BAD_WORDS = {"fuck","shit","bitch","asshole","bastard"}  # extend as needed; consider loading from file

LINK_REGEX = re.compile(r"https?://\S+|www\.\S+", re.IGNORECASE)

# ------------------ Cog ------------------
class Moderator(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.cleanup_cache.start()

    def cog_unload(self):
        self.cleanup_cache.cancel()
        save_json(SETTINGS_FILE, server_settings)
        save_json(WARN_FILE, warnings_store)

    # ---------------- Commands ----------------
    @app_commands.command(name="kick", description="Kick a member from the server")
    @app_commands.checks.has_permissions(kick_members=True)
    async def kick(self, interaction: discord.Interaction, member: discord.Member, reason: str = "No reason provided"):
        if is_protected(member):
            return await interaction.response.send_message("❌ That member is protected (admin/mod).", ephemeral=True)
        try:
            await member.kick(reason=reason)
            await interaction.response.send_message(f"✅ {member.mention} kicked. Reason: {reason}")
            embed = discord.Embed(title="Member Kicked", color=discord.Color.orange(), timestamp=datetime.utcnow())
            embed.add_field(name="User", value=f"{member} ({member.id})", inline=True)
            embed.add_field(name="By", value=f"{interaction.user} ({interaction.user.id})", inline=True)
            embed.add_field(name="Reason", value=reason, inline=False)
            await send_mod_log(interaction.guild, embed)
        except discord.Forbidden:
            await interaction.response.send_message("❌ I don't have permission to kick that member.", ephemeral=True)

    @app_commands.command(name="ban", description="Ban a member from the server")
    @app_commands.checks.has_permissions(ban_members=True)
    async def ban(self, interaction: discord.Interaction, member: discord.Member, reason: str = "No reason provided"):
        if is_protected(member):
            return await interaction.response.send_message("❌ That member is protected (admin/mod).", ephemeral=True)
        try:
            await member.ban(reason=reason)
            await interaction.response.send_message(f"✅ {member.mention} banned. Reason: {reason}")
            embed = discord.Embed(title="Member Banned", color=discord.Color.red(), timestamp=datetime.utcnow())
            embed.add_field(name="User", value=f"{member} ({member.id})", inline=True)
            embed.add_field(name="By", value=f"{interaction.user} ({interaction.user.id})", inline=True)
            embed.add_field(name="Reason", value=reason, inline=False)
            await send_mod_log(interaction.guild, embed)
        except discord.Forbidden:
            await interaction.response.send_message("❌ I don't have permission to ban that member.", ephemeral=True)

    @app_commands.command(name="unban", description="Unban a user ID from the server")
    @app_commands.checks.has_permissions(ban_members=True)
    async def unban(self, interaction: discord.Interaction, user_id: int):
        try:
            user = await self.bot.fetch_user(user_id)
        except Exception:
            return await interaction.response.send_message("❌ Invalid user ID.", ephemeral=True)

        banned_users = await interaction.guild.bans()
        if any(b.user.id == user_id for b in banned_users):
            await interaction.guild.unban(user)
            await interaction.response.send_message(f"✅ {user} has been unbanned.")
            embed = discord.Embed(title="Member Unbanned", color=discord.Color.green(), timestamp=datetime.utcnow())
            embed.add_field(name="User", value=f"{user} ({user.id})", inline=True)
            embed.add_field(name="By", value=f"{interaction.user} ({interaction.user.id})", inline=True)
            await send_mod_log(interaction.guild, embed)
        else:
            await interaction.response.send_message("❌ That user is not banned.", ephemeral=True)

    @app_commands.command(name="timeout", description="Timeout (mute) a member for seconds")
    @app_commands.checks.has_permissions(moderate_members=True)
    async def timeout(self, interaction: discord.Interaction, member: discord.Member, duration: int, reason: str = "No reason provided"):
        if is_protected(member):
            return await interaction.response.send_message("❌ That member is protected.", ephemeral=True)
        try:
            until = discord.utils.utcnow() + timedelta(seconds=duration)
            await member.timeout(until, reason=reason)
            await interaction.response.send_message(f"✅ Timed out {member.mention} for {duration}s. Reason: {reason}")
            embed = discord.Embed(title="Member Timed Out", color=discord.Color.blurple(), timestamp=datetime.utcnow())
            embed.add_field(name="User", value=f"{member} ({member.id})")
            embed.add_field(name="By", value=f"{interaction.user} ({interaction.user.id})")
            embed.add_field(name="Duration (s)", value=str(duration))
            embed.add_field(name="Reason", value=reason, inline=False)
            await send_mod_log(interaction.guild, embed)
        except discord.Forbidden:
            await interaction.response.send_message("❌ I don't have permission to timeout that member.", ephemeral=True)

    @app_commands.command(name="clear", description="Delete messages from the current channel")
    @app_commands.checks.has_permissions(manage_messages=True)
    async def clear(self, interaction: discord.Interaction, amount: int):
        try:
            deleted = await interaction.channel.purge(limit=amount)
            await interaction.response.send_message(f"✅ Deleted {len(deleted)} messages.", ephemeral=True)
            embed = discord.Embed(title="Messages Purged", color=discord.Color.orange(), timestamp=datetime.utcnow())
            embed.add_field(name="Channel", value=f"{interaction.channel.mention}")
            embed.add_field(name="By", value=f"{interaction.user.mention}")
            embed.add_field(name="Amount", value=str(len(deleted)))
            await send_mod_log(interaction.guild, embed)
        except discord.Forbidden:
            await interaction.response.send_message("❌ I don't have permission to delete messages here.", ephemeral=True)

    @app_commands.command(name="warn", description="Warn a member")
    @app_commands.checks.has_permissions(kick_members=True)
    async def warn(self, interaction: discord.Interaction, member: discord.Member, reason: str = "No reason provided"):
        if is_protected(member):
            return await interaction.response.send_message("❌ That member is protected.", ephemeral=True)
        g = str(interaction.guild.id)
        u = str(member.id)
        warnings_store.setdefault(g, {})
        warnings_store[g][u] = warnings_store[g].get(u, 0) + 1
        save_json(WARN_FILE, warnings_store)
        count = warnings_store[g][u]
        await interaction.response.send_message(f"⚠️ {member.mention} warned. Total warnings: {count}")
        embed = discord.Embed(title="User Warned", color=discord.Color.gold(), timestamp=datetime.utcnow())
        embed.add_field(name="User", value=f"{member} ({member.id})")
        embed.add_field(name="By", value=f"{interaction.user} ({interaction.user.id})")
        embed.add_field(name="Reason", value=reason)
        embed.add_field(name="Total Warnings", value=str(count))
        await send_mod_log(interaction.guild, embed)

        # automatic actions on warnings
        if count >= 3:
            try:
                await member.kick(reason="Reached warning threshold (3)")
                await interaction.followup.send(f"⚠️ {member.mention} kicked for reaching 3 warnings!")
                await send_mod_log(interaction.guild, discord.Embed(title="Auto-Kick (Warnings)", description=f"{member} auto-kicked after 3 warnings", color=discord.Color.orange()))
            except Exception:
                pass

    @app_commands.command(name="warnings", description="Check a member's warnings")
    @app_commands.checks.has_permissions(kick_members=True)
    async def check_warnings(self, interaction: discord.Interaction, member: discord.Member):
        g = str(interaction.guild.id)
        u = str(member.id)
        count = warnings_store.get(g, {}).get(u, 0)
        await interaction.response.send_message(f"ℹ️ {member.mention} has {count} warning(s).", ephemeral=True)

    @app_commands.command(name="clearwarnings", description="Clear a member's warnings")
    @app_commands.checks.has_permissions(kick_members=True)
    async def clear_warnings(self, interaction: discord.Interaction, member: discord.Member):
        g = str(interaction.guild.id)
        u = str(member.id)
        if g in warnings_store and u in warnings_store[g]:
            warnings_store[g][u] = 0
            save_json(WARN_FILE, warnings_store)
            await interaction.response.send_message(f"✅ {member.mention}'s warnings cleared.", ephemeral=True)
        else:
            await interaction.response.send_message("ℹ️ That user has no warnings.", ephemeral=True)

    # ---------------- Configuration Commands ----------------
    @app_commands.command(name="automod", description="Enable or disable automod")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def automod_toggle(self, interaction: discord.Interaction):
        cfg = ensure_guild_config(interaction.guild.id)
        cfg["automod"] = not cfg.get("automod", False)
        save_json(SETTINGS_FILE, server_settings)
        await interaction.response.send_message(f"✅ Automod {'enabled' if cfg['automod'] else 'disabled'}.", ephemeral=True)

    @app_commands.command(name="set_log_channel", description="Set channel for moderation logs")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def set_log_channel(self, interaction: discord.Interaction, channel: discord.TextChannel):
        cfg = ensure_guild_config(interaction.guild.id)
        cfg["log_channel"] = channel.id
        save_json(SETTINGS_FILE, server_settings)
        await interaction.response.send_message(f"✅ Moderation logs will be sent to {channel.mention}", ephemeral=True)

    @app_commands.command(name="set_welcome_channel", description="Set welcome channel")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def set_welcome_channel(self, interaction: discord.Interaction, channel: discord.TextChannel):
        cfg = ensure_guild_config(interaction.guild.id)
        cfg["welcome_channel"] = channel.id
        save_json(SETTINGS_FILE, server_settings)
        await interaction.response.send_message(f"✅ Welcome channel set to {channel.mention}", ephemeral=True)

    @app_commands.command(name="set_leave_channel", description="Set leave channel")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def set_leave_channel(self, interaction: discord.Interaction, channel: discord.TextChannel):
        cfg = ensure_guild_config(interaction.guild.id)
        cfg["leave_channel"] = channel.id
        save_json(SETTINGS_FILE, server_settings)
        await interaction.response.send_message(f"✅ Leave channel set to {channel.mention}", ephemeral=True)

    # ---------------- Listeners: caching for ghost ping ----------------
    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        # store into message cache (for ghost-ping detection)
        try:
            message_cache[message.id] = {
                "author_id": message.author.id,
                "mentions": [m.id for m in message.mentions],
                "content": message.content,
                "channel_id": message.channel.id,
                "created_at": message.created_at.isoformat()
            }
            # keep cache modest size
            if len(message_cache) > 2000:
                # pop oldest keys
                keys = list(message_cache.keys())[:200]
                for k in keys:
                    message_cache.pop(k, None)
        except Exception:
            pass

        # ignore bots, DMs
        if message.author.bot or message.guild is None:
            return

        cfg = ensure_guild_config(message.guild.id)
        if not cfg.get("automod"):
            return

        # protect staff
        if is_protected(message.author):
            return

        content = message.content.lower()

        # -------- banned words ----------
        for bw in BAD_WORDS:
            if bw in content:
                try:
                    await message.delete()
                except Exception:
                    pass
                await message.channel.send(f"⚠️ {message.author.mention}, that language is not allowed.", delete_after=8)
                # warning
                ensure_user_warns(message.guild.id, message.author.id)
                await send_mod_log(message.guild, discord.Embed(title="Automod: Bad Word", description=f"{message.author} used a banned word in {message.channel.mention}", color=discord.Color.dark_red()))
                return

        # -------- link filtering ----------
        if LINK_REGEX.search(message.content):
            # allow if user has manage_messages
            if not message.author.guild_permissions.manage_messages:
                try:
                    await message.delete()
                except Exception:
                    pass
                await message.channel.send(f"🚫 {message.author.mention}, links are not allowed here.", delete_after=8)
                await send_mod_log(message.guild, discord.Embed(title="Automod: Link Removed", description=f"User: {message.author}\nChannel: {message.channel.mention}\nContent: {message.content}", color=discord.Color.dark_orange()))
                return

        # -------- spam detection (rate) ----------
        ts = datetime.utcnow().timestamp()
        user_deque = recent_messages[message.guild.id][message.author.id]
        user_deque.append(ts)
        # count messages in window
        window = cfg.get("spam_window_seconds", DEFAULT_AUTOMOD["spam_window_seconds"])
        threshold = cfg.get("spam_threshold", DEFAULT_AUTOMOD["spam_threshold"])
        count_recent = sum(1 for t in user_deque if ts - t <= window)
        if count_recent >= threshold:
            # spam detected
            try:
                await message.channel.send(f"⚠️ {message.author.mention}, please stop spamming. You may be timed out.", delete_after=8)
            except Exception:
                pass
            # take action: timeout for short period
            try:
                await message.author.timeout(discord.utils.utcnow() + timedelta(seconds=30), reason="Spam detected by automod")
                await send_mod_log(message.guild, discord.Embed(title="Automod: Spam Timeout", description=f"{message.author} timed out for spamming", color=discord.Color.orange()))
            except Exception:
                pass
            # clear user's message deque to avoid repeated triggers
            recent_messages[message.guild.id][message.author.id].clear()
            return

    # detect ghost pings (message deleted that contained mentions)
    @commands.Cog.listener()
    async def on_message_delete(self, message: discord.Message):
        if message.guild is None:
            return
        # Try to fetch from our cache
        info = message_cache.pop(message.id, None)
        if not info:
            # message not cached; nothing we can do reliably
            return
        if info.get("mentions"):
            guild = message.guild
            chan = guild.get_channel(info.get("channel_id"))
            if chan:
                mention_users = [f"<@{m}>" for m in info["mentions"]]
                try:
                    await chan.send(f"👀 Ghost ping detected! {', '.join(mention_users)} were mentioned and the message was deleted.")
                    await send_mod_log(guild, discord.Embed(title="Automod: Ghost Ping", description=f"User <@{info['author_id']}> ghost-pinged {', '.join(mention_users)} in {chan.mention}", color=discord.Color.dark_gold()))
                except Exception:
                    pass

    # join raid detection: monitor joins within short timeframe
    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        gid = member.guild.id
        now = datetime.utcnow().timestamp()
        recent_joins[gid].append(now)
        cfg = ensure_guild_config(gid)
        # count joins in window
        window = cfg.get("raid_window_seconds", DEFAULT_AUTOMOD["raid_window_seconds"])
        threshold = cfg.get("raid_join_threshold", DEFAULT_AUTOMOD["raid_join_threshold"])
        count = sum(1 for t in recent_joins[gid] if now - t <= window)
        if count >= threshold:
            # possible raid
            try:
                # lock down: restrict @everyone from sending messages (requires manage_roles/manage_channels)
                everyone = member.guild.default_role
                for ch in member.guild.text_channels:
                    try:
                        await ch.set_permissions(everyone, send_messages=False)
                    except Exception:
                        pass
                await send_mod_log(member.guild, discord.Embed(title="Automod: Possible Raid", description=f"{count} joins detected within {window}s. Server temporarily locked.", color=discord.Color.red()))
                # Inform server owner via DM if possible
                owner = member.guild.owner
                try:
                    await owner.send(f"⚠️ Your server `{member.guild.name}` experienced possible raid activity. I have attempted to lock text channels. Check the server immediately.")
                except Exception:
                    pass
            except Exception:
                pass
        # welcome messages if enabled
        cfg = server_settings.get(str(gid), {})
        if cfg.get("welcome"):
            ch_id = cfg.get("welcome_channel")
            if ch_id:
                ch = member.guild.get_channel(ch_id)
                if ch:
                    try:
                        await ch.send(f"🎉 Welcome {member.mention} to {member.guild.name}!")
                    except Exception:
                        pass

    # ---------------- Error handling for app commands ----------------
    @commands.Cog.listener()
    async def on_app_command_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError):
        # handle common errors gracefully
        if isinstance(error, app_commands.MissingPermissions):
            await interaction.response.send_message("❌ You don't have permission to use this command.", ephemeral=True)
        elif isinstance(error, app_commands.CommandOnCooldown):
            await interaction.response.send_message("⏳ Command is on cooldown.", ephemeral=True)
        else:
            # fallback
            try:
                await interaction.response.send_message(f"❌ An error occurred: {error}", ephemeral=True)
            except Exception:
                pass

    # ---------------- Background cleanup: prune old joins/messages ----------------
    @tasks.loop(minutes=5)
    async def cleanup_cache(self):
        # prune message cache older than 10 minutes
        cutoff = datetime.utcnow() - timedelta(minutes=10)
        to_remove = []
        for mid, info in list(message_cache.items()):
            try:
                created = datetime.fromisoformat(info.get("created_at"))
                if created < cutoff:
                    to_remove.append(mid)
            except Exception:
                to_remove.append(mid)
        for mid in to_remove:
            message_cache.pop(mid, None)
        # prune old join timestamps older than 5 minutes
        for gid, dq in list(recent_joins.items()):
            now = datetime.utcnow().timestamp()
            while dq and now - dq[0] > 300:
                dq.popleft()

    @cleanup_cache.before_loop
    async def before_cleanup(self):
        await self.bot.wait_until_ready()

# ---------------- setup ----------------
async def setup(bot: commands.Bot):
    await bot.add_cog(Moderator(bot))