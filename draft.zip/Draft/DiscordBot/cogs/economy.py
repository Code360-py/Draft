import discord
from discord.ext import commands
from discord import app_commands
import json
import os
import random
from datetime import datetime, timedelta

ECONOMY_FILE = 'data/economy.json'

# ===================== Persistent Storage =====================
if os.path.exists(ECONOMY_FILE):
    with open(ECONOMY_FILE, "r") as f:
        economy_data = json.load(f)
else:
    economy_data = {}

def save_data():
    with open(ECONOMY_FILE, "w") as f:
        json.dump(economy_data, f, indent=4)

def ensure_user(guild_id, user_id):
    guild_id = str(guild_id)
    user_id = str(user_id)
    if guild_id not in economy_data:
        economy_data[guild_id] = {}
    if user_id not in economy_data[guild_id]:
        economy_data[guild_id][user_id] = {}
    
    # Ensure all default keys exist
    user_data = economy_data[guild_id][user_id]
    defaults = {
        "wallet": 0,
        "bank": 0,
        "last_daily": None,
        "last_weekly": None,
        "items": {},
        "cooldowns": {}
    }
    for key, value in defaults.items():
        if key not in user_data:
            user_data[key] = value

# ===================== Cooldown Helper =====================
def check_cooldown(user_data, name, seconds):
    last = user_data["cooldowns"].get(name)
    now = datetime.utcnow()
    if last:
        last_time = datetime.fromisoformat(last)
        if now - last_time < timedelta(seconds=seconds):
            remaining = timedelta(seconds=seconds) - (now - last_time)
            return False, remaining
    user_data["cooldowns"][name] = now.isoformat()
    return True, None

# ===================== Master Economy Cog =====================
class MasterEconomy(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    # ===================== Balance =====================
    @app_commands.command(name="balance", description="Check your wallet & bank balance")
    async def balance(self, interaction: discord.Interaction, member: discord.Member = None):
        member = member or interaction.user
        ensure_user(interaction.guild.id, member.id)
        data = economy_data[str(interaction.guild.id)][str(member.id)]
        embed = discord.Embed(
            title=f"{member.display_name}'s Balance",
            color=discord.Color.green()
        )
        embed.add_field(name="Wallet", value=f"₹{data['wallet']}")
        embed.add_field(name="Bank", value=f"₹{data['bank']}")
        if "items" in data and data["items"]:
            items = ", ".join([f"{k} x{v}" for k, v in data["items"].items()])
            embed.add_field(name="Items", value=items, inline=False)
        await interaction.response.send_message(embed=embed)

    # ===================== Deposit =====================
    @app_commands.command(name="deposit", description="Deposit money to your bank")
    async def deposit(self, interaction: discord.Interaction, amount: int):
        ensure_user(interaction.guild.id, interaction.user.id)
        data = economy_data[str(interaction.guild.id)][str(interaction.user.id)]
        if amount <= 0:
            return await interaction.response.send_message("❌ Amount must be greater than 0.", ephemeral=True)
        if data["wallet"] < amount:
            return await interaction.response.send_message("❌ Not enough money in wallet.", ephemeral=True)
        data["wallet"] -= amount
        data["bank"] += amount
        save_data()
        await interaction.response.send_message(f"✅ Deposited ₹{amount} to your bank.")

    # ===================== Withdraw =====================
    @app_commands.command(name="withdraw", description="Withdraw money from your bank")
    async def withdraw(self, interaction: discord.Interaction, amount: int):
        ensure_user(interaction.guild.id, interaction.user.id)
        data = economy_data[str(interaction.guild.id)][str(interaction.user.id)]
        if amount <= 0:
            return await interaction.response.send_message("❌ Amount must be greater than 0.", ephemeral=True)
        if data["bank"] < amount:
            return await interaction.response.send_message("❌ Not enough money in bank.", ephemeral=True)
        data["bank"] -= amount
        data["wallet"] += amount
        save_data()
        await interaction.response.send_message(f"✅ Withdrawn ₹{amount} from your bank.")

    # ===================== Transfer =====================
    @app_commands.command(name="transfer", description="Transfer money to another member")
    async def transfer(self, interaction: discord.Interaction, member: discord.Member, amount: int):
        if member == interaction.user:
            return await interaction.response.send_message("❌ You cannot transfer to yourself.", ephemeral=True)
        ensure_user(interaction.guild.id, interaction.user.id)
        ensure_user(interaction.guild.id, member.id)
        sender = economy_data[str(interaction.guild.id)][str(interaction.user.id)]
        receiver = economy_data[str(interaction.guild.id)][str(member.id)]
        if amount <= 0:
            return await interaction.response.send_message("❌ Amount must be greater than 0.", ephemeral=True)
        if sender["wallet"] < amount:
            return await interaction.response.send_message("❌ Not enough money in wallet.", ephemeral=True)
        sender["wallet"] -= amount
        receiver["wallet"] += amount
        save_data()
        await interaction.response.send_message(f"✅ Transferred ₹{amount} to {member.mention}.")

    # ===================== Daily Reward =====================
    @app_commands.command(name="daily", description="Claim your daily reward")
    async def daily(self, interaction: discord.Interaction):
        ensure_user(interaction.guild.id, interaction.user.id)
        user_data = economy_data[str(interaction.guild.id)][str(interaction.user.id)]
        now = datetime.utcnow()
        last_daily = user_data.get("last_daily")
        if last_daily:
            last = datetime.fromisoformat(last_daily)
            if now - last < timedelta(hours=24):
                remaining = timedelta(hours=24) - (now - last)
                return await interaction.response.send_message(f"⏳ Daily reward already claimed. Try again in {str(remaining).split('.')[0]}.", ephemeral=True)
        reward = random.randint(100, 500)
        user_data["wallet"] += reward
        user_data["last_daily"] = now.isoformat()
        save_data()
        await interaction.response.send_message(f"✅ You claimed your daily reward of ₹{reward}!")

    # ===================== Weekly Reward =====================
    @app_commands.command(name="weekly", description="Claim your weekly reward")
    async def weekly(self, interaction: discord.Interaction):
        ensure_user(interaction.guild.id, interaction.user.id)
        user_data = economy_data[str(interaction.guild.id)][str(interaction.user.id)]
        now = datetime.utcnow()
        last_weekly = user_data.get("last_weekly")
        if last_weekly:
            last = datetime.fromisoformat(last_weekly)
            if now - last < timedelta(days=7):
                remaining = timedelta(days=7) - (now - last)
                return await interaction.response.send_message(f"⏳ Weekly reward already claimed. Try again in {str(remaining).split('.')[0]}.", ephemeral=True)
        reward = random.randint(500, 2000)
        user_data["wallet"] += reward
        user_data["last_weekly"] = now.isoformat()
        save_data()
        await interaction.response.send_message(f"✅ You claimed your weekly reward of ₹{reward}!")

    # ===================== Leaderboard =====================
    @app_commands.command(name="leaderboard", description="Show top 10 richest members")
    async def leaderboard(self, interaction: discord.Interaction):
        guild_id = str(interaction.guild.id)
        ensure_user(interaction.guild.id, interaction.user.id)
        data = economy_data.get(guild_id, {})
        leaderboard = sorted(data.items(), key=lambda x: x[1]["wallet"] + x[1]["bank"], reverse=True)[:10]
        embed = discord.Embed(title="💰 Economy Leaderboard", color=discord.Color.gold())
        for i, (user_id, bal) in enumerate(leaderboard, start=1):
            member = interaction.guild.get_member(int(user_id))
            name = member.display_name if member else f"User ID {user_id}"
            total = bal["wallet"] + bal["bank"]
            embed.add_field(name=f"{i}. {name}", value=f"₹{total}", inline=False)
        await interaction.response.send_message(embed=embed)

    # ===================== Coinflip Gambling =====================
    @app_commands.command(name="coinflip", description="Bet on coinflip: heads or tails")
    async def coinflip(self, interaction: discord.Interaction, choice: str, amount: int):
        choice = choice.lower()
        if choice not in ["heads", "tails"]:
            return await interaction.response.send_message("❌ Choose `heads` or `tails`.", ephemeral=True)
        ensure_user(interaction.guild.id, interaction.user.id)
        user_data = economy_data[str(interaction.guild.id)][str(interaction.user.id)]
        if amount <= 0:
            return await interaction.response.send_message("❌ Bet must be greater than 0.", ephemeral=True)
        if user_data["wallet"] < amount:
            return await interaction.response.send_message("❌ Not enough money in wallet.", ephemeral=True)
        user_data["wallet"] -= amount
        result = random.choice(["heads", "tails"])
        if result == choice:
            winnings = amount * 2
            user_data["wallet"] += winnings
            save_data()
            await interaction.response.send_message(f"🎉 Coinflip result: {result}. You won ₹{winnings}!")
        else:
            save_data()
            await interaction.response.send_message(f"💀 Coinflip result: {result}. You lost ₹{amount}.")

    # ===================== Rob Command =====================
    @app_commands.command(name="rob", description="Attempt to rob another user")
    async def rob(self, interaction: discord.Interaction, member: discord.Member):
        if member == interaction.user:
            return await interaction.response.send_message("❌ You cannot rob yourself.", ephemeral=True)
        ensure_user(interaction.guild.id, interaction.user.id)
        ensure_user(interaction.guild.id, member.id)
        robber = economy_data[str(interaction.guild.id)][str(interaction.user.id)]
        victim = economy_data[str(interaction.guild.id)][str(member.id)]
        allowed, remaining = check_cooldown(robber, "rob", 3600)  # 1h cooldown
        if not allowed:
            return await interaction.response.send_message(f"⏳ Rob cooldown. Try again in {str(remaining).split('.')[0]}", ephemeral=True)
        if victim["wallet"] < 100:
            return await interaction.response.send_message("❌ Victim doesn't have enough money.", ephemeral=True)
        success = random.random() < 0.5
        if success:
            stolen = random.randint(50, min(500, victim["wallet"]))
            robber["wallet"] += stolen
            victim["wallet"] -= stolen
            save_data()
            await interaction.response.send_message(f"💰 Success! You stole ₹{stolen} from {member.mention}.")
        else:
            lost = random.randint(10, 100)
            robber["wallet"] -= lost
            save_data()
            await interaction.response.send_message(f"💀 Failed! You got caught and lost ₹{lost}.")

    # ===================== Admin Reset Economy =====================
    @app_commands.command(name="resetbank", description="Reset economy for a member (owner only)")
    async def resetbank(self, interaction: discord.Interaction, member: discord.Member):
        app_info = await self.bot.application_info()
        if interaction.user.id != app_info.owner.id:
            return await interaction.response.send_message("❌ Only bot owner can use this command.", ephemeral=True)
        ensure_user(interaction.guild.id, member.id)
        economy_data[str(interaction.guild.id)][str(member.id)] = {
            "wallet": 0,
            "bank": 0,
            "last_daily": None,
            "last_weekly": None,
            "items": {},
            "cooldowns": {}
        }
        save_data()
        await interaction.response.send_message(f"✅ Economy reset for {member.mention}.")

# ===================== Cog Setup =====================
async def setup(bot: commands.Bot):
    await bot.add_cog(MasterEconomy(bot))