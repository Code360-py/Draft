# cogs/server_enhance.py
import discord
from discord.ext import commands, tasks
from discord import app_commands
import json
import os
import asyncio

CONFIG_PATH = "data/server_templates.json"
os.makedirs(os.path.dirname(CONFIG_PATH) or ".", exist_ok=True)

def load_config():
    if not os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH, "w") as f:
            json.dump({}, f)
    with open(CONFIG_PATH, "r") as f:
        return json.load(f)

def save_config(cfg):
    with open(CONFIG_PATH, "w") as f:
        json.dump(cfg, f, indent=4)

# Roles perms mapping used when creating roles
ROLE_PERMS = {
    "Owner": discord.Permissions(administrator=True),
    "Admin": discord.Permissions(administrator=True),
    "Moderator": discord.Permissions(kick_members=True, ban_members=True, manage_messages=True, manage_channels=True),
    "Economy Manager": discord.Permissions(manage_guild=True, manage_messages=True),
    "Clan Leader": discord.Permissions(manage_guild=True, manage_messages=True),
    "Developer": discord.Permissions(send_messages=True),
    "Member": discord.Permissions(send_messages=True, read_messages=True),
    "Muted": discord.Permissions(send_messages=False, speak=False),
    "Bot": discord.Permissions(send_messages=True, manage_messages=True)
}

# Template definitions (channels lists)
TEMPLATES = {
    "full_aio": {
        "label": "Full AIO (All features)",
        "categories": {
            "📢 INFORMATION": ["rules", "announcements", "bot-updates", "welcome", "faq"],
            "🤖 BOT SYSTEM": ["bot-commands", "slash-commands", "bot-status", "suggestions"],
            "💰 ECONOMY": ["daily-rewards", "economy-logs", "transactions", "giveaways", "shop"],
            "🧰 JOBS & BADGES": ["job-apply", "job-updates", "xp-leaderboard", "badge-showcase"],
            "⚔ CLANS & COMPETITION": ["clan-chat", "clan-leaderboard", "team-battles", "war-updates", "nominee-voting"],
            "🗳 POLLS": ["polls", "public-votes", "leader-nomination"],
            "📈 ANALYTICS": ["server-logs", "bot-logs", "user-logs", "audit-trail", "errors-report"],
            "🧪 DEV ZONE": ["code-runner", "snippets", "output-results"],
            "🎉 FUN": ["memes", "gif-commands", "waifu-pics", "anime-zone", "jokes"],
            "👮 MODERATION": ["mod-chat", "mod-logs", "warnings", "auto-mod"],
            "🎧 VOICE": ["General VC", "Music VC", "Study VC", "Gaming VC", "AFK"]
        },
        "roles": ["Owner", "Admin", "Moderator", "Economy Manager", "Clan Leader", "Developer", "Member", "Muted", "Bot"]
    },

    "developer": {
        "label": "Developer Community",
        "categories": {
            "📢 INFORMATION": ["rules", "announcements", "bot-updates", "welcome"],
            "💻 DEVELOPMENT": ["frontend", "backend", "devops", "ai-ml", "projects"],
            "🗃 RESOURCES": ["free-tools", "ebooks", "source-codes"],
            "🧠 HELP": ["ask-questions", "code-review", "bugs"],
            "🎧 VOICE": ["General VC", "Coding VC", "AFK"]
        },
        "roles": ["Owner", "Admin", "Moderator", "Developer", "Frontend", "Backend", "AI/ML", "Member", "Muted", "Bot"]
    },

    "friends": {
        "label": "Friends Hangout",
        "categories": {
            "📢 INFO": ["rules", "announcements"],
            "💬 CHAT": ["general", "photos", "memes", "relationship-talk"],
            "🎮 GAMES": ["battles", "invite-codes"],
            "🎵 MUSIC": ["music-commands"],
            "🎧 VOICE": ["General VC", "Chill VC", "AFK"]
        },
        "roles": ["Owner", "Admin", "VIP", "Member", "Muted", "Bot"]
    },

    "clan": {
        "label": "Gaming Clan",
        "categories": {
            "⚔ CLAN HQ": ["rules", "announcements", "clan-updates"],
            "🎮 MATCHES": ["scrims", "tournaments", "rank-updates"],
            "🔥 CLAN RANKS": ["warriors", "elite", "champions"],
            "💬 COMMUNITY": ["general-chat", "highlights", "clips"],
            "🎧 VOICE": ["General VC", "Team VC 1", "Team VC 2", "AFK"]
        },
        "roles": ["Owner", "Clan Leader", "Co-Leader", "Elite", "Member", "Muted", "Bot"]
    },

    "economy": {
        "label": "Economy Focused",
        "categories": {
            "💰 ECONOMY": ["daily-rewards", "economy-logs", "transactions", "shop", "bank-requests"],
            "📈 LEADERBOARDS": ["wealth-leaderboard", "xp-leaderboard"],
            "💬 COMMUNITY": ["general", "trade"],
            "🎧 VOICE": ["Trading VC", "General VC"]
        },
        "roles": ["Owner", "Admin", "Economy Manager", "Trader", "Member", "Muted", "Bot"]
    },

    "fun": {
        "label": "Fun & Entertainment",
        "categories": {
            "🎉 FUN": ["memes", "gif-commands", "waifu-pics", "anime-zone", "jokes"],
            "🎵 MUSIC": ["music-requests", "top-tracks"],
            "🎮 GAMES": ["game-lobbies", "matchmaking"],
            "🎧 VOICE": ["Music VC", "Chill VC", "AFK"]
        },
        "roles": ["Owner", "Admin", "VIP", "Member", "Muted", "Bot"]
    }
}

class TemplateSelect(discord.ui.View):
    def __init__(self, parent_cog, *, timeout=180):
        super().__init__(timeout=timeout)
        self.parent = parent_cog
        options = [discord.SelectOption(label=data["label"], value=key, description=f"Deploy the {data['label']} template") for key, data in TEMPLATES.items()]
        self.add_item(discord.ui.Select(placeholder="Choose a template to deploy", options=options, custom_id="server_template_select"))

    @discord.ui.select(custom_id="server_template_select")
    async def select_callback(self, select: discord.ui.Select, interaction: discord.Interaction):
        # deploy chosen template
        if not interaction.user.guild_permissions.administrator:
            return await interaction.response.send_message("❌ Only admins can deploy templates.", ephemeral=True)

        choice = select.values[0]
        await interaction.response.defer(ephemeral=True)
        await self.parent.deploy_template(interaction.guild, choice, actor=interaction.user)
        await interaction.followup.send(f"✅ Deployed template **{TEMPLATES[choice]['label']}**", ephemeral=True)
        self.stop()

class ServerEnhance(commands.Cog):
    """ServerEnhance: Template-based, persistent, auto-fix, welcome and more."""
    def __init__(self, bot):
        self.bot = bot
        self.cfg = load_config()
        self.autofix.start()

    def cog_unload(self):
        self.autofix.cancel()

    # ---------- top-level autoset: shows menu and button ----------
    @app_commands.command(name="autoset", description="Open server template deploy menu or deploy full AIO. Use subcommands: menu | full")
    async def autoset(self, interaction: discord.Interaction):
        # show a small menu view with both options: menu (select) or quick full deploy button
        if not interaction.user.guild_permissions.administrator:
            return await interaction.response.send_message("❌ Only admins can use this command.", ephemeral=True)

        view = discord.ui.View(timeout=180)

        # Button: Quick Full Deploy
        async def quick_full_callback(button_interaction: discord.Interaction):
            if not button_interaction.user.guild_permissions.administrator:
                return await button_interaction.response.send_message("❌ Admins only.", ephemeral=True)
            await button_interaction.response.defer(ephemeral=True)
            await self.deploy_template(button_interaction.guild, "full_aio", actor=button_interaction.user)
            await button_interaction.followup.send("✅ Full AIO template deployed.", ephemeral=True)
            view.stop()

        full_btn = discord.ui.Button(label="Quick Deploy: Full AIO", style=discord.ButtonStyle.primary)
        full_btn.callback = quick_full_callback
        view.add_item(full_btn)

        # Button: Open Template Select
        async def open_menu_callback(btn_interaction: discord.Interaction):
            if not btn_interaction.user.guild_permissions.administrator:
                return await btn_interaction.response.send_message("❌ Admins only.", ephemeral=True)
            menu = TemplateSelect(self)
            await btn_interaction.response.send_message("Choose a template:", view=menu, ephemeral=True)
            view.stop()

        menu_btn = discord.ui.Button(label="Open Template Select", style=discord.ButtonStyle.secondary)
        menu_btn.callback = open_menu_callback
        view.add_item(menu_btn)

        await interaction.response.send_message("Choose deploy option:", view=view, ephemeral=True)

    # ---------- direct subcommand for menu (optional) ----------
    @app_commands.command(name="autoset_menu", description="Open template select menu")
    async def autoset_menu(self, interaction: discord.Interaction):
        if not interaction.user.guild_permissions.administrator:
            return await interaction.response.send_message("❌ Admins only.", ephemeral=True)
        view = TemplateSelect(self)
        await interaction.response.send_message("Select a server template to deploy:", view=view, ephemeral=True)

    # ---------- direct subcommand for full deploy ----------
    @app_commands.command(name="autoset_full", description="Quick deploy Full AIO template (one-click)")
    async def autoset_full(self, interaction: discord.Interaction):
        if not interaction.user.guild_permissions.administrator:
            return await interaction.response.send_message("❌ Admins only.", ephemeral=True)
        await interaction.response.defer(ephemeral=True)
        await self.deploy_template(interaction.guild, "full_aio", actor=interaction.user)
        await interaction.followup.send("✅ Full AIO template deployed.", ephemeral=True)

    # ---------- welcome setter ----------
    @app_commands.command(name="setwelcome", description="Set welcome channel and message (use {user} placeholder)")
    async def setwelcome(self, interaction: discord.Interaction, channel: discord.TextChannel, message: str):
        if not interaction.user.guild_permissions.administrator:
            return await interaction.response.send_message("❌ Admins only.", ephemeral=True)
        gid = str(interaction.guild.id)
        self.cfg.setdefault(gid, {})
        self.cfg[gid]["welcome"] = {"channel_id": channel.id, "message": message}
        save_config(self.cfg)
        await interaction.response.send_message(f"✅ Welcome set to {channel.mention}", ephemeral=True)

    # ---------- core deploy routine ----------
    async def deploy_template(self, guild: discord.Guild, template_key: str, actor: discord.Member | None = None):
        """Create roles, categories and channels for chosen template; save config for autofix."""
        data = TEMPLATES.get(template_key)
        if not data:
            raise ValueError("Invalid template key")

        # Create roles
        created_roles = []
        for rname in data.get("roles", []):
            if discord.utils.get(guild.roles, name=rname) is None:
                perms = ROLE_PERMS.get(rname, discord.Permissions(send_messages=True))
                role = await guild.create_role(name=rname, permissions=perms)
                created_roles.append(role.name)

        # Create categories and channels
        created_channels = []
        for cat_name, ch_list in data.get("categories", {}).items():
            category = discord.utils.get(guild.categories, name=cat_name)
            if category is None:
                category = await guild.create_category(cat_name)

            for ch_name in ch_list:
                if any(token.lower() in ch_name.lower() for token in ("vc", "voice")) or ch_name.endswith(" VC") or "VC" in ch_name:
                    if not discord.utils.get(guild.voice_channels, name=ch_name):
                        c = await guild.create_voice_channel(ch_name, category=category)
                        created_channels.append(f"VC: {c.name}")
                else:
                    if not discord.utils.get(guild.text_channels, name=ch_name):
                        c = await guild.create_text_channel(ch_name, category=category)
                        created_channels.append(f"TXT: {c.name}")

        # Ensure Muted role perms across channels
        muted = discord.utils.get(guild.roles, name="Muted")
        if muted:
            for ch in guild.channels:
                try:
                    await ch.set_permissions(muted, send_messages=False, speak=False, add_reactions=False)
                except Exception:
                    pass

        # Save template to config for autosync/autofix
        gid = str(guild.id)
        self.cfg.setdefault(gid, {})
        self.cfg[gid]["template"] = template_key
        self.cfg[gid]["structure"] = data  # store channels & role names
        self.cfg[gid].setdefault("welcome", self.cfg[gid].get("welcome"))  # keep existing welcome if any
        save_config(self.cfg)

        # Logging (send a small report to the user who invoked if available)
        if actor:
            try:
                await actor.send(f"Server template '{data['label']}' deployed on guild: {guild.name}. Roles created: {created_roles}. Channels created: {created_channels}")
            except Exception:
                pass

    # ---------- autofix background task ----------
    @tasks.loop(minutes=10)
    async def autofix(self):
        # iterate guilds for which we have saved template structure
        for gid, info in list(self.cfg.items()):
            if "structure" not in info:
                continue
            guild = self.bot.get_guild(int(gid))
            if not guild:
                continue
            structure = info["structure"]

            # ensure roles exist
            for rname in structure.get("roles", []):
                if not discord.utils.get(guild.roles, name=rname):
                    perms = ROLE_PERMS.get(rname, discord.Permissions(send_messages=True))
                    try:
                        await guild.create_role(name=rname, permissions=perms)
                    except Exception:
                        pass

            # ensure categories & channels
            for cat_name, ch_list in structure.get("categories", {}).items():
                category = discord.utils.get(guild.categories, name=cat_name)
                if category is None:
                    try:
                        category = await guild.create_category(cat_name)
                    except Exception:
                        continue

                for ch_name in ch_list:
                    if any(token.lower() in ch_name.lower() for token in ("vc", "voice")) or ch_name.endswith(" VC") or "VC" in ch_name:
                        if not discord.utils.get(guild.voice_channels, name=ch_name):
                            try:
                                await guild.create_voice_channel(ch_name, category=category)
                            except Exception:
                                pass
                    else:
                        if not discord.utils.get(guild.text_channels, name=ch_name):
                            try:
                                await guild.create_text_channel(ch_name, category=category)
                            except Exception:
                                pass

    @autofix.before_loop
    async def wait_ready(self):
        await self.bot.wait_until_ready()

    # ---------- events: welcome & minimal automod ----------
    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        gid = str(member.guild.id)
        conf = self.cfg.get(gid, {})
        welcome = conf.get("welcome")
        if welcome:
            ch = member.guild.get_channel(welcome.get("channel_id"))
            if ch:
                msg = welcome.get("message", "Welcome {user}!").replace("{user}", member.mention).replace("{name}", member.name)
                embed = discord.Embed(title=f"Welcome {member.display_name}!", description=msg, color=discord.Color.green())
                try:
                    await ch.send(embed=embed)
                except Exception:
                    pass

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot:
            return

        # Basic auto-moderation rules (non-intrusive)
        guild = message.guild
        if not guild:
            return

        # 1) banned words (simple example — customize as needed)
        banned = ["badword1", "badword2", "badword3"]
        content = message.content.lower()
        if any(b in content for b in banned):
            try:
                await message.delete()
                await message.channel.send(f"⚠️ {message.author.mention} please avoid using offensive language.", delete_after=8)
            except Exception:
                pass
            return

        # 2) links protection for basic channels (allow mods/admins)
        if ("http://" in content or "https://" in content) and not message.author.guild_permissions.manage_messages:
            # allow links in bot-commands or designated channels (improve by checking config)
            allowed_channels = ["bot-commands", "slash-commands", "music-requests"]
            if message.channel.name not in allowed_channels:
                try:
                    await message.delete()
                    await message.channel.send(f"🚫 Links are restricted here, {message.author.mention}", delete_after=8)
                except Exception:
                    pass
                return

# setup
async def setup(bot):
    await bot.add_cog(ServerEnhance(bot))