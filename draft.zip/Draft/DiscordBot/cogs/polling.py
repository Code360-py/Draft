import discord
from discord.ext import commands, tasks
from discord import app_commands
from discord.ui import View, Button
import asyncio

# In-memory storage for polls
active_polls = {}

class PollView(View):
    def __init__(self, poll_id, options):
        super().__init__(timeout=None)
        self.poll_id = poll_id
        self.options = options
        self.votes = {option: 0 for option in options}

        for option in options:
            self.add_item(Button(label=option, style=discord.ButtonStyle.primary, custom_id=f"{poll_id}:{option}"))

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        # Optional: restrict voting to certain roles/members
        return True

    @discord.ui.button(label="Dummy", style=discord.ButtonStyle.secondary, custom_id="dummy", row=0)
    async def dummy_button(self, interaction: discord.Interaction, button: Button):
        pass  # placeholder to avoid empty View error

    async def on_timeout(self):
        # Remove poll after timeout
        active_polls.pop(self.poll_id, None)

class Polling(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    # ===================== /poll =====================
    @app_commands.command(name="poll", description="Create a poll with options")
    @app_commands.describe(question="Question for the poll", options="Comma-separated options")
    async def poll(self, interaction: discord.Interaction, question: str, options: str):
        option_list = [opt.strip() for opt in options.split(",")]
        if len(option_list) < 2:
            return await interaction.response.send_message("❌ You must provide at least 2 options.")

        poll_id = f"{interaction.guild.id}-{interaction.id}"
        view = PollView(poll_id, option_list)
        active_polls[poll_id] = view

        embed = discord.Embed(title=question, description="\n".join(f"{opt}: 0 votes" for opt in option_list), color=discord.Color.blue())
        await interaction.response.send_message(embed=embed, view=view)

    # ===================== /clanleader =====================
    @app_commands.command(name="clanleader", description="Start clan leader nomination poll")
    @app_commands.describe(clan="Clan name", nominees="Comma-separated nominee names")
    async def clanleader(self, interaction: discord.Interaction, clan: str, nominees: str):
        nominee_list = [n.strip() for n in nominees.split(",")]
        if len(nominee_list) < 2:
            return await interaction.response.send_message("❌ At least 2 nominees required.")

        poll_id = f"clan-{interaction.guild.id}-{interaction.id}"
        view = PollView(poll_id, nominee_list)
        active_polls[poll_id] = view

        embed = discord.Embed(title=f"Clan Leader Nomination for {clan}",
                              description="\n".join(f"{n}: 0 votes" for n in nominee_list),
                              color=discord.Color.gold())
        await interaction.response.send_message(embed=embed, view=view)

# ===================== Cog Setup =====================
async def setup(bot):
    await bot.add_cog(Polling(bot))