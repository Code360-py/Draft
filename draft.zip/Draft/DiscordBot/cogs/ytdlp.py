import discord
from discord.ext import commands
from discord import app_commands
import yt_dlp
import os

DOWNLOAD_FOLDER = os.path.join(os.getcwd(), "downloads")
os.makedirs(DOWNLOAD_FOLDER, exist_ok=True)

class YTDLP(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    # ===================== /music =====================
    @app_commands.command(name="music", description="Download YouTube audio by URL or search query")
    async def music(self, interaction: discord.Interaction, query: str):
        await interaction.response.defer()

        ydl_opts = {
            "format": "bestaudio/best",
            "noplaylist": True,
            "quiet": True,
            "outtmpl": f"{DOWNLOAD_FOLDER}/%(title)s.%(ext)s",
            "postprocessors": [{
                "key": "FFmpegExtractAudio",
                "preferredcodec": "mp3",
                "preferredquality": "192",
            }],
        }

        if not query.startswith("http"):
            query = f"ytsearch:{query}"

        try:
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(query, download=True)

                # if it’s a search result, take first entry
                if "entries" in info:
                    info = info["entries"][0]

                # actual mp3 file name
                filename = os.path.join(
                    DOWNLOAD_FOLDER, f"{info['title']}.mp3"
                )

        except Exception as e:
            return await interaction.followup.send(f"❌ Error downloading audio: {str(e)}")

        # Send file / fallback
        if os.path.exists(filename) and os.path.getsize(filename) < 8 * 1024 * 1024:
            await interaction.followup.send(file=discord.File(filename))
        else:
            await interaction.followup.send(
                f"✅ Downloaded `{os.path.basename(filename)}`! File too large for Discord. Saved locally."
            )

    # ===================== /video =====================
    @app_commands.command(name="video", description="Download YouTube video by URL or search query")
    async def video(self, interaction: discord.Interaction, query: str):
        await interaction.response.defer()

        ydl_opts = {
            "format": "best",
            "noplaylist": True,
            "quiet": True,
            "outtmpl": f"{DOWNLOAD_FOLDER}/%(title)s.%(ext)s",
        }

        if not query.startswith("http"):
            query = f"ytsearch:{query}"

        try:
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(query, download=True)

                if "entries" in info:
                    info = info["entries"][0]

                filename = ydl.prepare_filename(info)

        except Exception as e:
            return await interaction.followup.send(f"❌ Error downloading video: {str(e)}")

        if os.path.getsize(filename) < 8 * 1024 * 1024:
            await interaction.followup.send(file=discord.File(filename))
        else:
            await interaction.followup.send(
                f"✅ Downloaded `{os.path.basename(filename)}`! File too large for Discord. Saved locally."
            )

async def setup(bot):
    await bot.add_cog(YTDLP(bot))