import discord
from discord.ext import commands
from discord import app_commands
from discord.ui import View, Select, Button

class Help(commands.Cog):
    """Interactive help command with categories, select menus, and buttons"""

    def __init__(self, bot):
        self.bot = bot

    # ===================== Help Slash Command =====================
    @app_commands.command(name="help", description="Interactive help menu")
    async def help(self, interaction: discord.Interaction):
        # Gather cogs and commands
        categories = {}
        for cog_name, cog in self.bot.cogs.items():
            commands_list = [
                f"/{c.name} - {c.description}" for c in cog.get_app_commands()
            ]
            categories[cog_name] = commands_list or ["No commands available"]

        # Create select menu options
        options = [
            discord.SelectOption(label=cog, description=f"{len(commands_list)} commands")
            for cog, commands_list in categories.items()
        ]

        # Select menu callback
        async def select_callback(select_interaction: discord.Interaction):
            selected_cog = select.values[0]
            commands_text = "\n".join(categories[selected_cog])
            embed = discord.Embed(
                title=f"{selected_cog} Commands",
                description=commands_text,
                color=discord.Color.blurple()
            )
            await select_interaction.response.edit_message(embed=embed)

        # Create select menu
        select = Select(
            placeholder="Choose a category...",
            options=options,
            min_values=1,
            max_values=1
        )
        select.callback = select_callback

        # Create a reset button
        async def reset_callback(button_interaction: discord.Interaction):
            await button_interaction.response.edit_message(
                embed=discord.Embed(
                    title="Help Menu",
                    description="Select a category from the dropdown below to see its commands.",
                    color=discord.Color.green()
                )
            )

        reset_button = Button(label="Reset", style=discord.ButtonStyle.secondary)
        reset_button.callback = reset_callback

        view = View()
        view.add_item(select)
        view.add_item(reset_button)

        # Send initial help message
        embed = discord.Embed(
            title="Help Menu",
            description="Select a category from the dropdown below to see its commands.",
            color=discord.Color.green()
        )
        await interaction.response.send_message(embed=embed, view=view)

# ===================== Cog Setup =====================
async def setup(bot):
    await bot.add_cog(Help(bot))