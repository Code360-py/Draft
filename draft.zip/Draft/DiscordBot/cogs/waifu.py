import discord
from discord.ext import commands
from discord import app_commands
import aiohttp
import random

class Fun(commands.Cog):
    """Fun commands: Waifu, GIFs, memes, jokes, anime, and more"""

    def __init__(self, bot):
        self.bot = bot
        self.nsfw_enabled = {}  # Store per-guild NSFW toggle

    # ===================== NSFW Toggle =====================
    @app_commands.command(name="nsfw_toggle", description="Enable or disable NSFW content in your server")
    async def nsfw_toggle(self, interaction: discord.Interaction):
        guild_id = str(interaction.guild.id)
        current = self.nsfw_enabled.get(guild_id, False)
        self.nsfw_enabled[guild_id] = not current
        await interaction.response.send_message(f"✅ NSFW content {'enabled' if not current else 'disabled'}.")
        
    # ===================== Waifu Image =====================
    @app_commands.command(name="waifu", description="Get a random waifu image")
    async def waifu(self, interaction: discord.Interaction, category: str = "waifu"):
        async with aiohttp.ClientSession() as session:
            async with session.get(f"https://api.waifu.im/search?included_tags={category}") as resp:
                if resp.status != 200:
                    return await interaction.response.send_message("❌ Could not fetch waifu image.")
                data = await resp.json()
                image_url = data['images'][0]['url']
                await interaction.response.send_message(image_url)

    # ===================== Random Meme =====================
    @app_commands.command(name="fun_meme", description="Get a random meme")
    async def fun_meme(self, interaction: discord.Interaction):
        async with aiohttp.ClientSession() as session:
            async with session.get("https://meme-api.com/gimme") as resp:
                if resp.status != 200:
                    return await interaction.response.send_message("❌ Could not fetch meme.")
                data = await resp.json()
                embed = discord.Embed(title=data['title'], url=data['postLink'])
                embed.set_image(url=data['url'])
                embed.set_footer(text=f"👍 {data['ups']} | Author: {data['author']}")
                await interaction.response.send_message(embed=embed)

    # ===================== Random GIF =====================
    @app_commands.command(name="gif", description="Get a random GIF")
    @app_commands.describe(query="Search query for GIF")
    async def gif(self, interaction: discord.Interaction, query: str = "funny"):
        API_KEY = "YOUR_TENOR_API_KEY"  # Free Tenor API
        async with aiohttp.ClientSession() as session:
            async with session.get(f"https://tenor.googleapis.com/v2/search?q={query}&key={API_KEY}&limit=10") as resp:
                if resp.status != 200:
                    num = random.randint(1, 100)
                    url = f'https://www.dieoff.org/wp-content/uploads/2023/04/naked-gif-{num}.gif'
                    return await interaction.response.send_message(url)
                data = await resp.json()
                gif_url = random.choice(data['results'])['media_formats']['gif']['url']
                await interaction.response.send_message(gif_url)

    # ===================== 8Ball =====================
    @app_commands.command(name="8ball", description="Ask the magic 8-ball a question")
    async def eightball(self, interaction: discord.Interaction, question: str):
        responses = [
            "Yes.", "No.", "Maybe.", "Definitely.", "Absolutely not.",
            "Ask again later.", "I have no idea.", "Certainly!"
        ]
        await interaction.response.send_message(f"🎱 Question: {question}\nAnswer: {random.choice(responses)}")

    # ===================== Random Joke =====================
    @app_commands.command(name="fun_joke", description="Get a random joke")
    async def fun_joke(self, interaction: discord.Interaction):
        async with aiohttp.ClientSession() as session:
            async with session.get("https://v2.jokeapi.dev/joke/Any?type=single") as resp:
                if resp.status != 200:
                    return await interaction.response.send_message("❌ Could not fetch joke.")
                data = await resp.json()
                await interaction.response.send_message(data["joke"])

# ===================== Cog Setup =====================
async def setup(bot):
    await bot.add_cog(Fun(bot))