import discord
from discord.ext import commands
from discord import app_commands
import json, os, random
from datetime import datetime, timedelta

CLAN_FILE = 'data/clans.json'

# ===================== Data Manager =====================
if os.path.exists(CLAN_FILE):
    with open(CLAN_FILE, "r") as f:
        clan_data = json.load(f)
else:
    clan_data = {}

def save():
    with open(CLAN_FILE, "w") as f:
        json.dump(clan_data, f, indent=4)

def ensure_guild(guild_id):
    guild_id = str(guild_id)
    if guild_id not in clan_data:
        clan_data[guild_id] = {
            "users": {},
            "clans": {},
            "log_channel": None
        }

def ensure_user(guild_id, user_id):
    ensure_guild(guild_id)
    user_id = str(user_id)
    if user_id not in clan_data[str(guild_id)]["users"]:
        clan_data[str(guild_id)]["users"][user_id] = {
            "xp": 0,
            "level": 1,
            "clan": None,
            "last_daily": None,
            "boost_active": False
        }

def ensure_clan(guild_id, clan_name):
    ensure_guild(guild_id)
    if clan_name not in clan_data[str(guild_id)]["clans"]:
        clan_data[str(guild_id)]["clans"][clan_name] = {
            "owner": None,
            "members": [],
            "role_id": None,
            "category_id": None,
            "text_id": None,
            "voice_id": None,
            "xp": 0,
            "level": 1,
            "locked": False,
        }

# ===================== Level Formula =====================
def xp_to_level(xp):
    return max(1, int((xp/100) ** 0.6))

def add_xp(guild_id, user_id, amount):
    ensure_user(guild_id, user_id)
    user = clan_data[str(guild_id)]["users"][str(user_id)]

    # boosters
    if user.get("boost_active", False):
        amount = int(amount * 1.5)

    clan_name = user["clan"]
    user["xp"] += amount
    old = user["level"]
    user["level"] = xp_to_level(user["xp"])

    leveled = user["level"] > old

    # Add XP to clan
    if clan_name:
        clan = clan_data[str(guild_id)]["clans"][clan_name]
        clan["xp"] += amount
        clan["level"] = xp_to_level(clan["xp"])

    save()
    return leveled

# ===================== Logging Helper =====================
async def log_event(guild, message):
    guild_id = str(guild.id)
    log_id = clan_data[guild_id].get("log_channel")
    if log_id:
        channel = guild.get_channel(log_id)
        if channel:
            await channel.send(message)

# ===================== CLAN SYSTEM =====================
class Clan(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    # ========= Admin Set Log Channel =========
    @app_commands.command(name="set_clan_logs", description="Set a channel for clan system logs")
    async def set_clan_logs(self, interaction: discord.Interaction, channel: discord.TextChannel):
        if not interaction.user.guild_permissions.administrator:
            return await interaction.response.send_message("❌ Admins only.", ephemeral=True)

        ensure_guild(interaction.guild.id)
        clan_data[str(interaction.guild.id)]["log_channel"] = channel.id
        save()
        await interaction.response.send_message(f"📘 Clan logs set to {channel.mention}")

    # ========= Create Clan =========
    @app_commands.command(name="create_clan", description="Create a new clan with private channels")
    async def create_clan(self, interaction: discord.Interaction, name: str):
        guild = interaction.guild
        gid = str(guild.id)
        uid = str(interaction.user.id)

        ensure_user(gid, uid)
        user = clan_data[gid]["users"][uid]

        if user["clan"]:
            return await interaction.response.send_message("❌ You are already in a clan.", ephemeral=True)

        ensure_clan(gid, name)
        clan = clan_data[gid]["clans"][name]

        if clan["owner"]:
            return await interaction.response.send_message("❌ Clan already exists.", ephemeral=True)

        # Create role
        role = await guild.create_role(name=name, mentionable=True)
        clan["role_id"] = role.id

        # Create private category + channels
        overwrites = {
            guild.default_role: discord.PermissionOverwrite(view_channel=False),
            role: discord.PermissionOverwrite(view_channel=True)
        }

        category = await guild.create_category(name=f"🏰 {name} Clan", overwrites=overwrites)
        clan["category_id"] = category.id

        text = await category.create_text_channel("clan-chat")
        voice = await category.create_voice_channel("Clan VC")

        clan["text_id"] = text.id
        clan["voice_id"] = voice.id

        # Assign owner
        clan["owner"] = uid
        clan["members"].append(uid)
        user["clan"] = name
        await interaction.user.add_roles(role)

        save()

        await interaction.response.send_message(f"✅ Clan **{name}** created with private channels!")
        await log_event(guild, f"🏰 Clan `{name}` created by {interaction.user.mention}")

    # ========= Join Clan =========
    @app_commands.command(name="join_clan", description="Join an existing clan")
    async def join_clan(self, interaction: discord.Interaction, name: str):
        guild = interaction.guild
        gid = str(guild.id)
        uid = str(interaction.user.id)

        ensure_user(gid, uid)
        user = clan_data[gid]["users"][uid]

        if user["clan"]:
            return await interaction.response.send_message("❌ You already belong to a clan.", ephemeral=True)

        if name not in clan_data[gid]["clans"]:
            return await interaction.response.send_message("❌ Clan not found.", ephemeral=True)

        clan = clan_data[gid]["clans"][name]

        role = guild.get_role(clan["role_id"])
        if role:
            await interaction.user.add_roles(role)

        clan["members"].append(uid)
        user["clan"] = name
        save()

        await interaction.response.send_message(f"✅ You joined **{name}**!")
        await log_event(guild, f"➕ {interaction.user.mention} joined `{name}`")

    # ========= Leave Clan =========
    @app_commands.command(name="leave_clan", description="Leave your clan")
    async def leave_clan(self, interaction: discord.Interaction):
        guild = interaction.guild
        gid = str(guild.id)
        uid = str(interaction.user.id)

        ensure_user(gid, uid)
        user = clan_data[gid]["users"][uid]

        cname = user["clan"]
        if not cname:
            return await interaction.response.send_message("❌ You are not in a clan.", ephemeral=True)

        clan = clan_data[gid]["clans"][cname]

        if uid == clan["owner"]:
            return await interaction.response.send_message("❌ Clan owners must transfer ownership first.", ephemeral=True)

        # Remove role
        role = guild.get_role(clan["role_id"])
        if role:
            await interaction.user.remove_roles(role)

        clan["members"].remove(uid)
        user["clan"] = None
        save()

        await interaction.response.send_message(f"👋 You left **{cname}**")
        await log_event(guild, f"➖ {interaction.user.mention} left `{cname}`")

    # ========= Daily Task =========
    @app_commands.command(name="daily_task", description="Complete your daily XP task")
    async def daily_task(self, interaction: discord.Interaction):
        gid = str(interaction.guild.id)
        uid = str(interaction.user.id)
        ensure_user(gid, uid)

        user = clan_data[gid]["users"][uid]
        now = datetime.utcnow()

        if user["last_daily"]:
            last = datetime.fromisoformat(user["last_daily"])
            if now - last < timedelta(hours=24):
                remain = timedelta(hours=24) - (now - last)
                return await interaction.response.send_message(
                    f"⏳ You already did daily. Try again in **{remain.seconds//3600}h**."
                )

        reward = random.randint(80, 200)
        leveled = add_xp(gid, uid, reward)

        user["last_daily"] = now.isoformat()
        save()

        msg = f"🎉 Daily complete! You earned **{reward} XP**."
        if leveled:
            msg += f"\n⬆️ Level up! Now **Level {user['level']}**"

        await interaction.response.send_message(msg)

    # ========= Clan Info =========
    @app_commands.command(name="clan_info", description="View information about your clan")
    async def clan_info(self, interaction: discord.Interaction):
        gid = str(interaction.guild.id)
        uid = str(interaction.user.id)

        ensure_user(gid, uid)
        cname = clan_data[gid]["users"][uid]["clan"]

        if not cname:
            return await interaction.response.send_message("❌ You are not in a clan.", ephemeral=True)

        clan = clan_data[gid]["clans"][cname]

        embed = discord.Embed(title=f"🏰 Clan: {cname}", color=discord.Color.blue())
        embed.add_field(name="Owner", value=f"<@{clan['owner']}>")
        embed.add_field(name="Members", value=len(clan["members"]))
        embed.add_field(name="Clan XP", value=clan["xp"])
        embed.add_field(name="Clan Level", value=clan["level"])

        await interaction.response.send_message(embed=embed)

# ===================== Setup =====================
async def setup(bot):
    await bot.add_cog(Clan(bot))