import discord
from discord.ext import commands, tasks
from discord import app_commands
import json
import os
from datetime import datetime, timedelta

TASK_FILE = 'data/tasks.json'
# ===================== Persistent Storage =====================
if os.path.exists(TASK_FILE):
    with open(TASK_FILE, "r") as f:
        task_data = json.load(f)
else:
    task_data = {}

def save_tasks():
    with open(TASK_FILE, "w") as f:
        json.dump(task_data, f, indent=4)

def ensure_user(guild_id, user_id):
    guild_id = str(guild_id)
    user_id = str(user_id)
    if guild_id not in task_data:
        task_data[guild_id] = {}
    if user_id not in task_data[guild_id]:
        task_data[guild_id][user_id] = {"tasks": []}

# ===================== TaskManager Cog =====================
class TaskManager(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.check_tasks.start()  # Start background task

    # ===================== Add Task =====================
    @app_commands.command(name="add_task", description="Add a task with optional reminder time")
    async def add_task(self, interaction: discord.Interaction, description: str, remind_in_minutes: int = None):
        guild_id = interaction.guild.id
        user_id = interaction.user.id
        ensure_user(guild_id, user_id)
        task = {
            "description": description,
            "created_at": datetime.utcnow().isoformat(),
            "completed": False
        }
        if remind_in_minutes:
            task["remind_at"] = (datetime.utcnow() + timedelta(minutes=remind_in_minutes)).isoformat()
        task_data[str(guild_id)][str(user_id)]["tasks"].append(task)
        save_tasks()
        msg = f"✅ Task added: `{description}`"
        if remind_in_minutes:
            msg += f" | Reminder in {remind_in_minutes} minutes"
        await interaction.response.send_message(msg)

    # ===================== List Tasks =====================
    @app_commands.command(name="list_tasks", description="List all your tasks")
    async def list_tasks(self, interaction: discord.Interaction):
        guild_id = interaction.guild.id
        user_id = interaction.user.id
        ensure_user(guild_id, user_id)
        tasks_list = task_data[str(guild_id)][str(user_id)]["tasks"]
        if not tasks_list:
            return await interaction.response.send_message("📋 You have no tasks.", ephemeral=True)
        embed = discord.Embed(title=f"{interaction.user.name}'s Tasks", color=discord.Color.blue())
        for i, t in enumerate(tasks_list, 1):
            status = "✅ Completed" if t.get("completed") else "❌ Pending"
            desc = t["description"]
            embed.add_field(name=f"{i}. {status}", value=desc, inline=False)
        await interaction.response.send_message(embed=embed)

    # ===================== Complete Task =====================
    @app_commands.command(name="complete_task", description="Mark a task as completed by index")
    async def complete_task(self, interaction: discord.Interaction, task_number: int):
        guild_id = interaction.guild.id
        user_id = interaction.user.id
        ensure_user(guild_id, user_id)
        tasks_list = task_data[str(guild_id)][str(user_id)]["tasks"]
        if not tasks_list or task_number < 1 or task_number > len(tasks_list):
            return await interaction.response.send_message("❌ Invalid task number.", ephemeral=True)
        tasks_list[task_number - 1]["completed"] = True
        save_tasks()
        await interaction.response.send_message(f"✅ Task `{tasks_list[task_number - 1]['description']}` marked as completed.")

    # ===================== Delete Task =====================
    @app_commands.command(name="delete_task", description="Delete a task by index")
    async def delete_task(self, interaction: discord.Interaction, task_number: int):
        guild_id = interaction.guild.id
        user_id = interaction.user.id
        ensure_user(guild_id, user_id)
        tasks_list = task_data[str(guild_id)][str(user_id)]["tasks"]
        if not tasks_list or task_number < 1 or task_number > len(tasks_list):
            return await interaction.response.send_message("❌ Invalid task number.", ephemeral=True)
        deleted_task = tasks_list.pop(task_number - 1)
        save_tasks()
        await interaction.response.send_message(f"🗑️ Task `{deleted_task['description']}` deleted.")

    # ===================== Daily Task Auto =====================
    @tasks.loop(minutes=60)
    async def check_tasks(self):
        now = datetime.utcnow()
        for guild_id, users in task_data.items():
            for user_id, data in users.items():
                for task in data["tasks"]:
                    if task.get("remind_at") and not task.get("completed"):
                        remind_time = datetime.fromisoformat(task["remind_at"])
                        if now >= remind_time:
                            user = self.bot.get_user(int(user_id))
                            if user:
                                try:
                                    await user.send(f"⏰ Reminder: `{task['description']}`")
                                    # Optional: remove reminder after sending
                                    task["remind_at"] = None
                                except discord.Forbidden:
                                    pass
        save_tasks()

    # ===================== Stop Background Task on Cog Unload =====================
    def cog_unload(self):
        self.check_tasks.cancel()

# ===================== Cog Setup =====================
async def setup(bot: commands.Bot):
    await bot.add_cog(TaskManager(bot))