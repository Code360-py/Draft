import discord
from discord.ext import commands
from discord.ext.commands import BucketType

class Basic(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    # ================= Hello Command =================
    @commands.command(name='hello', help='Greet the bot')
    @commands.cooldown(rate=1, per=5, type=BucketType.user)  # 1 use per 5 seconds per user
    async def hello_command(self, ctx):
        await ctx.reply(f'Hello **{ctx.author.mention}**! 👋')

    # ================= Ping Command =================
    @commands.command(name='ping', help='Check bot latency')
    @commands.cooldown(rate=1, per=3, type=BucketType.user)  # 1 use per 3 seconds
    async def ping_command(self, ctx):
        latency = round(self.bot.latency * 1000)
        await ctx.send(f'🏓 Pong! {latency}ms')

    # ================= Bot Info Command =================
    @commands.command(name='botinfo', help='Get bot information')
    async def botinfo(self, ctx):
        embed = discord.Embed(title="Bot Information", color=discord.Color.blurple())
        embed.add_field(name="Name", value=self.bot.user.name, inline=True)
        embed.add_field(name="ID", value=self.bot.user.id, inline=True)
        embed.add_field(name="Servers", value=len(self.bot.guilds), inline=True)
        embed.add_field(name="Users", value=len(self.bot.users), inline=True)
        embed.set_footer(text=f"Requested by {ctx.author}", icon_url=ctx.author.avatar.url)
        await ctx.send(embed=embed)

    # ================= User Info Command =================
    @commands.command(name='userinfo', help='Get information about a user')
    async def userinfo(self, ctx, member: discord.Member = None):
        member = member or ctx.author
        embed = discord.Embed(title=f"{member}'s Info", color=discord.Color.green())
        embed.add_field(name="ID", value=member.id, inline=True)
        embed.add_field(name="Display Name", value=member.display_name, inline=True)
        embed.add_field(name="Joined Server", value=member.joined_at.strftime("%d %b %Y"), inline=True)
        embed.add_field(name="Account Created", value=member.created_at.strftime("%d %b %Y"), inline=True)
        embed.set_thumbnail(url=member.avatar.url)
        await ctx.send(embed=embed)

    # ================= Server Info Command =================
    @commands.command(name='serverinfo', help='Get information about the server')
    async def serverinfo(self, ctx):
        guild = ctx.guild
        embed = discord.Embed(title=f"{guild.name} Server Info", color=discord.Color.gold())
        embed.add_field(name="Server ID", value=guild.id)
        embed.add_field(name="Owner", value=guild.owner)
        embed.add_field(name="Members", value=guild.member_count)
        embed.add_field(name="Text Channels", value=len(guild.text_channels))
        embed.add_field(name="Voice Channels", value=len(guild.voice_channels))
        embed.set_thumbnail(url=guild.icon.url if guild.icon else None)
        await ctx.send(embed=embed)

    # ================= Avatar Command =================
    @commands.command(name='avatar', help='Get avatar of a user')
    async def avatar(self, ctx, member: discord.Member = None):
        member = member or ctx.author
        embed = discord.Embed(title=f"{member}'s Avatar", color=discord.Color.purple())
        embed.set_image(url=member.avatar.url)
        await ctx.send(embed=embed)

    # ================= Say Command =================
    @commands.command(name='say', help='Make the bot say something')
    async def say(self, ctx, *, message: str):
        await ctx.message.delete()
        await ctx.send(message)

    # ================= Global Error Handler =================
    @commands.Cog.listener()
    async def on_command_error(self, ctx, error):
        if isinstance(error, commands.MissingRequiredArgument):
            await ctx.send(f"❌ Missing argument: `{error.param.name}`")
        elif isinstance(error, commands.CommandOnCooldown):
            await ctx.send(f"⏳ Command is on cooldown! Try again in {round(error.retry_after, 1)} seconds.")
        elif isinstance(error, commands.MemberNotFound):
            await ctx.send("❌ Member not found!")
        elif isinstance(error, commands.CommandNotFound):
            pass  # ignore unknown commands
        else:
            await ctx.send(f"❌ An error occurred: {str(error)}")

# ================= Cog Setup =================
async def setup(bot):
    await bot.add_cog(Basic(bot))