import discord
from discord.ext import commands
from discord import app_commands
import asyncio
import sys

class Admin(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    # ===================== Helper: Check Owner =====================
    async def is_owner(self, user: discord.User):
        app_info = await self.bot.application_info()
        return user.id == app_info.owner.id

    async def owner_only(self, interaction: discord.Interaction):
        if not await self.is_owner(interaction.user):
            await interaction.response.send_message("❌ Only the bot owner can use this command!", ephemeral=True)
            return False
        return True

    # ===================== Shutdown Bot =====================
    @app_commands.command(name="shutdown", description="Shut down the bot (owner only)")
    async def shutdown(self, interaction: discord.Interaction):
        if not await self.owner_only(interaction):
            return
        await interaction.response.send_message("⚠️ Shutting down...")
        await self.bot.close()

    # ===================== Cog Management =====================
    @app_commands.command(name="reload", description="Reload a cog (owner only)")
    async def reload(self, interaction: discord.Interaction, cog: str):
        if not await self.owner_only(interaction):
            return
        try:
            self.bot.unload_extension(f"cogs.{cog}")
            self.bot.load_extension(f"cogs.{cog}")
            await interaction.response.send_message(f"✅ Cog `{cog}` reloaded successfully.")
        except Exception as e:
            await interaction.response.send_message(f"❌ Failed to reload `{cog}`: {e}")

    @app_commands.command(name="load", description="Load a cog (owner only)")
    async def load(self, interaction: discord.Interaction, cog: str):
        if not await self.owner_only(interaction):
            return
        try:
            self.bot.load_extension(f"cogs.{cog}")
            await interaction.response.send_message(f"✅ Cog `{cog}` loaded successfully.")
        except Exception as e:
            await interaction.response.send_message(f"❌ Failed to load `{cog}`: {e}")

    @app_commands.command(name="unload", description="Unload a cog (owner only)")
    async def unload(self, interaction: discord.Interaction, cog: str):
        if not await self.owner_only(interaction):
            return
        try:
            self.bot.unload_extension(f"cogs.{cog}")
            await interaction.response.send_message(f"✅ Cog `{cog}` unloaded successfully.")
        except Exception as e:
            await interaction.response.send_message(f"❌ Failed to unload `{cog}`: {e}")

    # ===================== Set Bot Prefix =====================
    @app_commands.command(name="setprefix", description="Change bot prefix (owner only)")
    async def setprefix(self, interaction: discord.Interaction, prefix: str):
        if not await self.owner_only(interaction):
            return
        self.bot.command_prefix = prefix
        await interaction.response.send_message(f"✅ Bot prefix changed to `{prefix}`")

    # ===================== Server Info =====================
    @app_commands.command(name="serverinfo", description="Get server information")
    async def serverinfo(self, interaction: discord.Interaction):
        guild = interaction.guild
        embed = discord.Embed(title=f"{guild.name} Info", color=discord.Color.blue())
        embed.add_field(name="Server ID", value=guild.id)
        embed.add_field(name="Owner", value=guild.owner)
        embed.add_field(name="Members", value=guild.member_count)
        embed.add_field(name="Roles", value=len(guild.roles))
        embed.set_thumbnail(url=guild.icon.url if guild.icon else None)
        await interaction.response.send_message(embed=embed)

    # ===================== Broadcast Message =====================
    @app_commands.command(name="broadcast", description="Send a message to all text channels")
    async def broadcast(self, interaction: discord.Interaction, message: str):
        if not await self.owner_only(interaction):
            return
        sent_count = 0
        for channel in interaction.guild.text_channels:
            try:
                await channel.send(message)
                sent_count += 1
                await asyncio.sleep(0.5)  # prevent rate limit
            except:
                continue
        await interaction.response.send_message(f"✅ Broadcast sent to {sent_count} channels.")

    # ===================== DM Broadcast =====================
    @app_commands.command(name="dmall", description="DM all members in the server")
    async def dmall(self, interaction: discord.Interaction, message: str):
        if not await self.owner_only(interaction):
            return
        sent_count = 0
        for member in interaction.guild.members:
            if member.bot:
                continue
            try:
                await member.send(message)
                sent_count += 1
                await asyncio.sleep(0.5)  # prevent rate limit
            except:
                continue
        await interaction.response.send_message(f"✅ DM sent to {sent_count} members.")

    # ===================== Role Management =====================
    @app_commands.command(name="addrole", description="Add a role to a member")
    async def addrole(self, interaction: discord.Interaction, member: discord.Member, role: discord.Role):
        if not await self.owner_only(interaction):
            return
        try:
            await member.add_roles(role)
            await interaction.response.send_message(f"✅ Role {role.name} added to {member.mention}")
        except Exception as e:
            await interaction.response.send_message(f"❌ Failed to add role: {e}")

    @app_commands.command(name="removerole", description="Remove a role from a member")
    async def removerole(self, interaction: discord.Interaction, member: discord.Member, role: discord.Role):
        if not await self.owner_only(interaction):
            return
        try:
            await member.remove_roles(role)
            await interaction.response.send_message(f"✅ Role {role.name} removed from {member.mention}")
        except Exception as e:
            await interaction.response.send_message(f"❌ Failed to remove role: {e}")

    # ===================== Bot Info =====================
    @app_commands.command(name="botinfo", description="Show bot information")
    async def botinfo(self, interaction: discord.Interaction):
        app_info = await self.bot.application_info()
        embed = discord.Embed(title="Bot Information", color=discord.Color.green())
        embed.add_field(name="Bot Name", value=self.bot.user.name)
        embed.add_field(name="Bot ID", value=self.bot.user.id)
        embed.add_field(name="Owner", value=app_info.owner)
        embed.add_field(name="Servers", value=len(self.bot.guilds))
        await interaction.response.send_message(embed=embed)

    # ===================== Eval Command =====================
    @app_commands.command(name="eval", description="Evaluate Python code (owner only)")
    async def eval(self, interaction: discord.Interaction, code: str):
        if not await self.owner_only(interaction):
            return
        try:
            result = eval(code)
            await interaction.response.send_message(f"✅ Result: ```{result}```")
        except Exception as e:
            await interaction.response.send_message(f"❌ Error: ```{e}```")

# ===================== Cog Setup =====================
async def setup(bot: commands.Bot):
    await bot.add_cog(Admin(bot))