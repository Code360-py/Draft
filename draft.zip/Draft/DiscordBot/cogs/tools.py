import discord
from discord.ext import commands
from discord import app_commands
import aiohttp
import qrcode
from io import BytesIO
import random

class Tools(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    # ===================== 1️⃣ QR Code Generator =====================
    @app_commands.command(name="qrcode", description="Generate a QR code from text or URL")
    async def qrcode_command(self, interaction: discord.Interaction, text: str):
        img = qrcode.make(text)
        buffer = BytesIO()
        img.save(buffer, format="PNG")
        buffer.seek(0)
        file = discord.File(fp=buffer, filename="qrcode.png")
        await interaction.response.send_message("Here is your QR code:", file=file)

    # ===================== 2️⃣ News =====================
    @app_commands.command(name="news", description="Get latest news headlines")
    async def news(self, interaction: discord.Interaction, query: str = None):
        url = "https://newsapi.org/v2/top-headlines"
        params = {
            "country": "in",
            "apiKey": "YOUR_NEWSAPI_KEY",
            "q": query
        }
        async with aiohttp.ClientSession() as session:
            async with session.get(url, params=params) as resp:
                data = await resp.json()
        articles = data.get("articles", [])[:5]
        if not articles:
            return await interaction.response.send_message("❌ No news found.")
        embed = discord.Embed(title="📰 Latest News", color=discord.Color.blue())
        for a in articles:
            embed.add_field(name=a["title"], value=a.get("url", ""), inline=False)
        await interaction.response.send_message(embed=embed)

    # ===================== 3️⃣ Weather =====================
    @app_commands.command(name="weather", description="Get current weather for a city")
    async def weather(self, interaction: discord.Interaction, city: str):
        url = "http://api.openweathermap.org/data/2.5/weather"
        params = {
            "q": city,
            "appid": "YOUR_OPENWEATHER_KEY",
            "units": "metric"
        }
        async with aiohttp.ClientSession() as session:
            async with session.get(url, params=params) as resp:
                data = await resp.json()
        if data.get("cod") != 200:
            return await interaction.response.send_message(f"❌ City `{city}` not found.")
        desc = data["weather"][0]["description"].title()
        temp = data["main"]["temp"]
        humidity = data["main"]["humidity"]
        embed = discord.Embed(title=f"🌤 Weather in {city.title()}", color=discord.Color.green())
        embed.add_field(name="Condition", value=desc)
        embed.add_field(name="Temperature", value=f"{temp}°C")
        embed.add_field(name="Humidity", value=f"{humidity}%")
        await interaction.response.send_message(embed=embed)

    # ===================== 4️⃣ Pickup Line =====================
    @app_commands.command(name="pickup", description="Get a random pickup line")
    async def pickup(self, interaction: discord.Interaction):
        async with aiohttp.ClientSession() as session:
            async with session.get("https://api.popcatdev.repl.co/pickup") as resp:
                data = await resp.json()
        line = data.get("line", "You are amazing! 💖")
        await interaction.response.send_message(f"💌 Pickup Line: {line}")

    # ===================== 5️⃣ Joke =====================
    @app_commands.command(name="joke", description="Get a random joke")
    async def joke(self, interaction: discord.Interaction):
        async with aiohttp.ClientSession() as session:
            async with session.get("https://v2.jokeapi.dev/joke/Any") as resp:
                data = await resp.json()
        if data.get("type") == "single":
            joke = data["joke"]
        else:
            joke = f"{data['setup']} ... {data['delivery']}"
        await interaction.response.send_message(f"😂 Joke: {joke}")

    # ===================== 6️⃣ Random Fact =====================
    @app_commands.command(name="fact", description="Get a random fact")
    async def fact(self, interaction: discord.Interaction):
        async with aiohttp.ClientSession() as session:
            async with session.get("https://uselessfacts.jsph.pl/random.json?language=en") as resp:
                data = await resp.json()
        await interaction.response.send_message(f"📚 Fact: {data.get('text', 'No fact found.')}")

    # ===================== 7️⃣ Cat Image =====================
    @app_commands.command(name="cat", description="Get a random cat image")
    async def cat(self, interaction: discord.Interaction):
        async with aiohttp.ClientSession() as session:
            async with session.get("https://aws.random.cat/meow") as resp:
                data = await resp.json()
        await interaction.response.send_message(data.get("file"))

    # ===================== 8️⃣ Dog Image =====================
    @app_commands.command(name="dog", description="Get a random dog image")
    async def dog(self, interaction: discord.Interaction):
        async with aiohttp.ClientSession() as session:
            async with session.get("https://dog.ceo/api/breeds/image/random") as resp:
                data = await resp.json()
        await interaction.response.send_message(data.get("message"))

    # ===================== 9️⃣ Anime Quote =====================
    @app_commands.command(name="animequote", description="Get a random anime quote")
    async def animequote(self, interaction: discord.Interaction):
        async with aiohttp.ClientSession() as session:
            async with session.get("https://animechan.vercel.app/api/random") as resp:
                data = await resp.json()
        quote = f'"{data.get("quote")}" - {data.get("character")} ({data.get("anime")})'
        await interaction.response.send_message(f"🗨️ Anime Quote: {quote}")

    # ===================== 🔟 Advice =====================
    @app_commands.command(name="advice", description="Get a random advice")
    async def advice(self, interaction: discord.Interaction):
        async with aiohttp.ClientSession() as session:
            async with session.get("https://api.adviceslip.com/advice") as resp:
                data = await resp.json()
        advice = data.get("slip", {}).get("advice", "Always be positive!")
        await interaction.response.send_message(f"💡 Advice: {advice}")

    # ===================== 11️⃣ Chuck Norris Joke =====================
    @app_commands.command(name="chucknorris", description="Get a Chuck Norris joke")
    async def chucknorris(self, interaction: discord.Interaction):
        async with aiohttp.ClientSession() as session:
            async with session.get("https://api.chucknorris.io/jokes/random") as resp:
                data = await resp.json()
        await interaction.response.send_message(f"🥋 Chuck Norris: {data.get('value')}")

    # ===================== 12️⃣ Random Meme =====================
    @app_commands.command(name="meme", description="Get a random meme")
    async def meme(self, interaction: discord.Interaction):
        async with aiohttp.ClientSession() as session:
            async with session.get("https://meme-api.com/gimme") as resp:
                data = await resp.json()
        await interaction.response.send_message(f"🖼 Meme: {data.get('url')}")

# ===================== Cog Setup =====================
async def setup(bot):
    await bot.add_cog(Tools(bot))