import discord
from discord.ext import commands, tasks
from discord import app_commands
import datetime
import json
import os

ANALYTICS_FILE = "data/analytics.json"

# Ensure analytics file exists
if not os.path.exists(ANALYTICS_FILE):
    with open(ANALYTICS_FILE, "w") as f:
        json.dump({"servers": {}, "users": {}, "bot": {"commands": 0, "errors": 0, "uptime": str(datetime.datetime.utcnow())}}, f)

def load_data():
    with open(ANALYTICS_FILE, "r") as f:
        return json.load(f)

def save_data(data):
    with open(ANALYTICS_FILE, "w") as f:
        json.dump(data, f, indent=4)

class Analytics(commands.Cog):
    """Analytics and Audit Logging Cog"""
    def __init__(self, bot):
        self.bot = bot

    # ===================== Command Usage Tracker =====================
    @commands.Cog.listener()
    async def on_command_completion(self, ctx):
        data = load_data()
        data["bot"]["commands"] += 1
        # User command count
        user_id = str(ctx.author.id)
        data["users"].setdefault(user_id, {"commands": 0, "messages": 0, "warnings": 0})
        data["users"][user_id]["commands"] += 1
        save_data(data)

    # ===================== Error Logger =====================
    @commands.Cog.listener()
    async def on_command_error(self, ctx, error):
        data = load_data()
        data["bot"]["errors"] += 1
        save_data(data)
        # Optional: log detailed error
        print(f"[ERROR] Command: {ctx.command} User: {ctx.author} Error: {error}")

    # ===================== Member Join/Leave Logger =====================
    @commands.Cog.listener()
    async def on_member_join(self, member):
        data = load_data()
        guild_id = str(member.guild.id)
        data["servers"].setdefault(guild_id, {"joins": [], "leaves": [], "messages": {}})
        data["servers"][guild_id]["joins"].append({"member": member.name, "id": member.id, "time": str(datetime.datetime.utcnow())})
        save_data(data)

    @commands.Cog.listener()
    async def on_member_remove(self, member):
        data = load_data()
        guild_id = str(member.guild.id)
        data["servers"].setdefault(guild_id, {"joins": [], "leaves": [], "messages": {}})
        data["servers"][guild_id]["leaves"].append({"member": member.name, "id": member.id, "time": str(datetime.datetime.utcnow())})
        save_data(data)

    # ===================== Message Logger =====================
    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot:
            return
        data = load_data()
        guild_id = str(message.guild.id)
        channel_id = str(message.channel.id)
        user_id = str(message.author.id)

        data["servers"].setdefault(guild_id, {"joins": [], "leaves": [], "messages": {}})
        data["servers"][guild_id]["messages"].setdefault(channel_id, 0)
        data["servers"][guild_id]["messages"][channel_id] += 1

        data["users"].setdefault(user_id, {"commands": 0, "messages": 0, "warnings": 0})
        data["users"][user_id]["messages"] += 1
        save_data(data)

    # ===================== Analytics Commands =====================
    @app_commands.command(name="serverstats", description="Show server analytics")
    async def serverstats(self, interaction: discord.Interaction):
        guild_id = str(interaction.guild.id)
        data = load_data().get("servers", {}).get(guild_id, {})
        joins = len(data.get("joins", []))
        leaves = len(data.get("leaves", []))
        total_messages = sum(data.get("messages", {}).values())
        embed = discord.Embed(title=f"📊 {interaction.guild.name} Analytics", color=discord.Color.blue())
        embed.add_field(name="Joins", value=str(joins))
        embed.add_field(name="Leaves", value=str(leaves))
        embed.add_field(name="Total Messages", value=str(total_messages))
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="userstats", description="Show user analytics")
    async def userstats(self, interaction: discord.Interaction, user: discord.Member):
        user_id = str(user.id)
        data = load_data().get("users", {}).get(user_id, {})
        embed = discord.Embed(title=f"👤 {user.name} Analytics", color=discord.Color.green())
        embed.add_field(name="Commands Used", value=str(data.get("commands", 0)))
        embed.add_field(name="Messages Sent", value=str(data.get("messages", 0)))
        embed.add_field(name="Warnings", value=str(data.get("warnings", 0)))
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="botstats", description="Show bot analytics")
    async def botstats(self, interaction: discord.Interaction):
        data = load_data().get("bot", {})
        embed = discord.Embed(title="🤖 Bot Analytics", color=discord.Color.purple())
        embed.add_field(name="Commands Executed", value=str(data.get("commands", 0)))
        embed.add_field(name="Errors", value=str(data.get("errors", 0)))
        embed.add_field(name="Uptime", value=data.get("uptime", "Unknown"))
        await interaction.response.send_message(embed=embed)

# ===================== Cog Setup =====================
async def setup(bot):
    await bot.add_cog(Analytics(bot))