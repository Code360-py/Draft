import discord
from discord.ext import commands, tasks
from discord import app_commands
import json, os, random, datetime

DATA_FILE = "data/jobs.json"

if not os.path.exists(DATA_FILE):
    with open(DATA_FILE, "w") as f:
        json.dump({}, f)

def load_data():
    with open(DATA_FILE, "r") as f:
        return json.load(f)

def save_data(data):
    with open(DATA_FILE, "w") as f:
        json.dump(data, f, indent=4)

JOB_ROLES = {
    "Developer": {"xp_boost": 10, "daily_tasks": ["Code feature", "Fix bug", "Code review"]},
    "Designer": {"xp_boost": 8, "daily_tasks": ["Design mockup", "Update UI", "Create asset"]},
    "Tester": {"xp_boost": 5, "daily_tasks": ["Test feature", "Write report", "Bug verification"]},
    "SysAdmin": {"xp_boost": 7, "daily_tasks": ["Server backup", "Deploy update", "Monitor uptime"]},
    "Data Analyst": {"xp_boost": 6, "daily_tasks": ["Analyze data", "Create charts", "Generate report"]}
}

BADGES = ["Top Developer", "Bug Hunter", "MVP", "Creative Designer", "Efficient Tester"]

class Job(commands.Cog):
    """Advanced IT Sector Jobs Cog with XP, Badges, Tasks, Leaderboard"""

    def __init__(self, bot):
        self.bot = bot

    # ===================== Apply Job =====================
    @app_commands.command(name="applyjob", description="Apply for a job role")
    @app_commands.describe(role="Role to apply for")
    async def applyjob(self, interaction: discord.Interaction, role: str):
        role = role.title()
        if role not in JOB_ROLES:
            return await interaction.response.send_message(f"❌ Invalid role. Available: {', '.join(JOB_ROLES.keys())}")
        data = load_data()
        user_id = str(interaction.user.id)
        data.setdefault(user_id, {"job": None, "batch": None, "badges": [], "xp": 0, "civil_score": 0, "last_daily": None})
        data[user_id]["job"] = role
        data[user_id]["xp_boost"] = JOB_ROLES[role]["xp_boost"]
        save_data(data)
        await interaction.response.send_message(f"✅ {interaction.user.mention} applied as **{role}**! XP boost: {JOB_ROLES[role]['xp_boost']}%")

    # ===================== Daily Task =====================
    @app_commands.command(name="dailytask", description="Perform your daily job task to earn XP & civil score")
    async def dailytask(self, interaction: discord.Interaction):
        data = load_data()
        user_id = str(interaction.user.id)
        user_data = data.get(user_id)
        if not user_data or not user_data.get("job"):
            return await interaction.response.send_message("❌ You have no job. Apply using /applyjob.")

        today = str(datetime.date.today())
        if user_data.get("last_daily") == today:
            return await interaction.response.send_message("⏳ You have already completed your daily task today!")

        job = user_data["job"]
        task = random.choice(JOB_ROLES[job]["daily_tasks"])
        xp_earned = random.randint(5, 15) + user_data.get("xp_boost", 0)
        civil_score = random.randint(1, 5)
        user_data["xp"] += xp_earned
        user_data["civil_score"] += civil_score
        user_data["last_daily"] = today
        save_data(data)

        await interaction.response.send_message(f"✅ {interaction.user.mention} completed daily task **'{task}'**! XP +{xp_earned}, Civil Score +{civil_score}")

    # ===================== Check Job Info =====================
    @app_commands.command(name="myjob", description="Check your job, XP, badges, civil score")
    async def myjob(self, interaction: discord.Interaction):
        data = load_data()
        user_id = str(interaction.user.id)
        user_data = data.get(user_id)
        if not user_data or not user_data.get("job"):
            return await interaction.response.send_message("ℹ️ You currently have no job.")
        embed = discord.Embed(title=f"{interaction.user.name}'s Job Info", color=discord.Color.green())
        embed.add_field(name="Job Role", value=user_data["job"])
        embed.add_field(name="Batch", value=user_data.get("batch") or "Not assigned")
        embed.add_field(name="XP", value=user_data.get("xp", 0))
        embed.add_field(name="Civil Score", value=user_data.get("civil_score", 0))
        embed.add_field(name="Badges", value=", ".join(user_data.get("badges") or []) or "None")
        await interaction.response.send_message(embed=embed)

    # ===================== Assign Badge =====================
    @app_commands.command(name="assignbadge", description="Assign badge to a user (Admin only)")
    @app_commands.describe(user="User to assign badge", badge="Badge name")
    async def assignbadge(self, interaction: discord.Interaction, user: discord.Member, badge: str):
        if not interaction.user.guild_permissions.administrator:
            return await interaction.response.send_message("❌ Only admins can assign badges.")
        data = load_data()
        user_id = str(user.id)
        data.setdefault(user_id, {"job": None, "batch": None, "badges": [], "xp": 0, "civil_score": 0, "last_daily": None})
        if badge not in data[user_id]["badges"]:
            data[user_id]["badges"].append(badge)
        save_data(data)
        await interaction.response.send_message(f"✅ Badge **{badge}** assigned to {user.mention}.")

    # ===================== Assign Batch =====================
    @app_commands.command(name="assignbatch", description="Assign a batch to a user")
    @app_commands.describe(user="User to assign batch", batch="Batch name")
    async def assignbatch(self, interaction: discord.Interaction, user: discord.Member, batch: str):
        if not interaction.user.guild_permissions.administrator:
            return await interaction.response.send_message("❌ Only admins can assign batches.")
        data = load_data()
        user_id = str(user.id)
        data.setdefault(user_id, {"job": None, "batch": None, "badges": [], "xp": 0, "civil_score": 0, "last_daily": None})
        data[user_id]["batch"] = batch
        save_data(data)
        await interaction.response.send_message(f"✅ {user.mention} assigned to batch **{batch}**.")

    # ===================== Job Leaderboard =====================
    @app_commands.command(name="jobleaderboard", description="Show job leaderboard based on XP and civil score")
    async def jobleaderboard(self, interaction: discord.Interaction, job: str = None):
        data = load_data()
        leaderboard = []
        for user_id, user_data in data.items():
            if job and user_data.get("job") != job:
                continue
            leaderboard.append((user_id, user_data.get("xp", 0), user_data.get("civil_score", 0)))
        leaderboard.sort(key=lambda x: (x[1], x[2]), reverse=True)
        embed = discord.Embed(title=f"🏆 Job Leaderboard {f'({job})' if job else ''}", color=discord.Color.gold())
        for idx, (user_id, xp, civil) in enumerate(leaderboard[:10], start=1):
            user = interaction.guild.get_member(int(user_id))
            name = user.name if user else f"User({user_id})"
            embed.add_field(name=f"{idx}. {name}", value=f"XP: {xp} | Civil Score: {civil}", inline=False)
        await interaction.response.send_message(embed=embed)

    # ===================== Simulate Code Execution =====================
    @app_commands.command(name="run", description="Simulate running code (Python)")
    @app_commands.describe(code="Python code snippet")
    async def run(self, interaction: discord.Interaction, code: str):
        """Sandboxed basic code execution"""
        try:
            local_vars = {}
            exec(f"async def __code():\n{textwrap.indent(code, '    ')}", {}, local_vars)
            func = local_vars["__code"]
            await func()
            await interaction.response.send_message("✅ Code executed successfully!")
        except Exception as e:
            await interaction.response.send_message(f"❌ Error: {e}")

# ===================== Cog Setup =====================
async def setup(bot):
    await bot.add_cog(Job(bot))