import telebot, requests
import json, random, os
from dotenv import load_dotenv
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
from telebot.types import ReplyKeyboardMarkup, KeyboardButton
from telebot import types


load_dotenv()
Token = os.getenv('TOKEN')
bot = telebot.TeleBot(Token)
DOWNLOAD_DIR = "downloads"


bot.set_my_commands([
    # Neko
    types.BotCommand("hass", "lowkey cute neko vibes 🐱✨"),
    types.BotCommand("hmidriff", "showin’ that midriff flex 😏"),
    types.BotCommand("pgif", "funny/adorable gif drops 🎞️"),
    types.BotCommand("fourk", "highkey 4k quality pics 🔥"),
    types.BotCommand("hentai", "nsfw sneaky stuff 😳"),
    types.BotCommand("holo", "holo mood 😺"),
    types.BotCommand("hneko", "extra lewd neko energy 😼"),
    types.BotCommand("neko", "basic cute neko feels 🐾"),
    types.BotCommand("hkitsune", "fox girl flex 🦊💫"),
    types.BotCommand("kemonomimi", "animal ears, big vibes 🐰😎"),
    types.BotCommand("anal", "nsfw straight up 👀"),
    types.BotCommand("hanal", "hentai anal mode activated 😏"),
    types.BotCommand("gonewild", "no cap, wild content 🔥"),
    types.BotCommand("kanna", "cute Kanna energy 🐉💖"),
    types.BotCommand("ass", "booty shots, duh 🍑"),
    types.BotCommand("pussy", "nsfw cat energy 🐱😳"),
    types.BotCommand("thigh", "thigh flexes 🍑🔥"),
    types.BotCommand("hthigh", "extra spicy thighs 😏"),
    types.BotCommand("gah", "random chaos energy 😵"),
    types.BotCommand("coffee", "chill coffee vibes ☕"),
    types.BotCommand("food", "snack content 🍕🍣"),
    types.BotCommand("paizuri", "nsfw chest action 😳"),
    types.BotCommand("tentacle", "tentacle chaos 🐙😵"),
    types.BotCommand("boobs", "boob flex 💖"),
    types.BotCommand("hboobs", "extra spicy boobs 😏"),
    types.BotCommand("yaoi", "boys love energy 💕"),
    types.BotCommand("cosplay", "cosplay drip 👗✨"),
    types.BotCommand("swimsuit", "beach vibes 🌊👙"),
    types.BotCommand("pantsu", "panty flex 😳"),
    types.BotCommand("nakadashi", "nsfw stuff, lowkey intense 😏"),

    # Waifu
    types.BotCommand("maid", "cute maid drip 🧹✨"),
    types.BotCommand("waifu", "top tier waifu vibes 💖"),
    types.BotCommand("marin_kitagawa", "Marin mood 😎"),
    types.BotCommand("mori_calliope", "Mori aesthetic 🎤💀"),
    types.BotCommand("raiden_shogun", "Raiden flex ⚡"),
    types.BotCommand("oppai", "boob energy 🍑"),
    types.BotCommand("selfies", "waifu selfies 📸"),
    types.BotCommand("uniform", "school vibes 🏫✨"),
    types.BotCommand("kamisato_ayaka", "Ayaka mood ❄️💖"),
    types.BotCommand("milf", "mature flex 👑🔥"),
    types.BotCommand("oral", "nsfw vibes 👀"),
    types.BotCommand("ecchi", "mild nsfw fun 😅"),
    types.BotCommand("ero", "full lewd mode 😳")
])


NEKO_TAGS = [
    "hass", "hmidriff", "pgif", "4k", "hentai", "holo",
    "hneko", "neko", "hkitsune", "kemonomimi", "anal",
    "hanal", "gonewild", "kanna", "ass", "pussy", "thigh",
    "hthigh", "gah", "coffee", "food", "paizuri", "tentacle", 
    "boobs", "hboobs", "yaoi", "cosplay", "swimsuit", "pantsu", "nakadashi"
]


WAIFU_TAGS = [
    "maid", "waifu", "marin-kitagawa", "mori-calliope",
    "raiden-shogun", "oppai", "selfies", "uniform",
    "kamisato-ayaka", "ass", "hentai",
    "milf", "oral", "paizuri", "ecchi", "ero"
]


@bot.message_handler(commands=['start'])
def start(message):
    text = (
        f"Hello {message.chat.username}!\n"
        f"Welcome to NekoBot your Dream world!!"
    )
    rkb = ReplyKeyboardMarkup(resize_keyboard=True)
    rkb.add(KeyboardButton('Subscribe'), KeyboardButton('GitHub'))
    bot.send_message(message.chat.id, text, reply_markup=rkb)


@bot.message_handler(commands=NEKO_TAGS)
def neko_tags_handler(message):
    tag = message.text.replace("/", "")
    image = requests.get(f"https://nekobot.xyz/api/image?type={tag}").json()["message"]
    bot.send_photo(message.chat.id, photo=image)
    
    
@bot.message_handler(commands=WAIFU_TAGS)
def waifu_tags_handler(message):
    tag = message.text.replace("/", "")
    res = requests.get(f"https://api.waifu.im/search?included_tags={tag}").json()
    image = res["images"][0]["url"]
    bot.send_photo(message.chat.id, photo=image)
    
    
@bot.message_handler(commands=WAIFU_TAGS)
def audio_handler(message):
    try:
        audio = open('audio.mp3', 'rb')
    except:
        audio = None
    bot.send_audio(message.chat.id, audio=audio)
    
    
@bot.message_handler(commands=['gif'])
def gif_handler(message):
    url1 = f"https://www.dieoff.org/wp-content/uploads/2023/04/naked-gif-{random.randint(0, 100)}.gif"
    url2 = f"https://www.dieoff.org/wp-content/uploads/2022/06/erotic-gif-{random.randint(0, 100)}.gif"
    #url3 = f"https://xgifer.com/content/2022/12/anal-dildo-pussy-skinny_0{random.randint(0, 100)}.gif"    
    bot.send_animation(message.chat.id, random.choice([url1, url2]))
    
    
@bot.message_handler(content_types=['document', 'photo', 'audio', 'video', 'voice', 'sticker'])
def file_handle(message):
    try:
        if message.content_type == 'document':
            file_id = message.document.file_id
            file_name = message.document.file_name
        elif message.content_type == 'photo':
            file_id = message.photo[-1].file_id
            file_name = f"{file_id}.jpg"
        elif message.content_type == 'audio':
            file_id = message.audio.file_id
            file_name = message.audio.file_name 
        elif message.content_type == 'video':
            file_id = message.video.file_id
            file_name = message.video.file_name or f"{file_id}.mp4"
        elif message.content_type == 'voice':
            file_id = message.voice.file_id
            file_name = f"{file_id}.ogg"
        elif message.content_type == 'sticker':
            file_id = message.sticker.file_id
            file_name = f"{file_id}.webp"
            
        file_info = bot.get_file(file_id)
        downloaded_file = bot.download_file(file_info.file_path)
        local_file_path = os.path.join(DOWNLOAD_DIR, file_name)
        
        with open(local_file_path, 'wb') as new_file:
            new_file.write(downloaded_file)            
        bot.reply_to(message, f"File saved successfully as: {local_file_path}")

    except Exception as e:
        bot.reply_to(message, f"An error occurred: {e}")
        

@bot.message_handler(commands=['playful'])
def gif_handler(message):
    if not stickers["sticker_ids"]:
        bot.send_message(message.chat.id, "Yo fam, I got no stickers saved yet 👀")
        return
    sticker = random.choice(stickers["sticker_ids"])
    bot.send_sticker(message.chat.id, sticker)
    
        
@bot.message_handler(commands=['nekomenu', 'waifumenu'])    
def list_handler(message):
    message_id = message.message_id
    if message.text == "/nekomenu":
        kb = InlineKeyboardMarkup(row_width=4)
        kb.add(*[InlineKeyboardButton(text, callback_data=text) for text in NEKO_TAGS])
        bot.send_message(message.chat.id, "Choose an option:", reply_markup=kb)
            
    if message.text == "/waifumenu":
        kb = InlineKeyboardMarkup(row_width=4)
        kb.add(*[InlineKeyboardButton(text, callback_data=text) for text in WAIFU_TAGS])
        bot.send_message(message.chat.id, "Choose an option:", reply_markup=kb)
        
        
@bot.callback_query_handler(func=lambda call: True)
def callback_handler(call):
    data = call.data
    user_id = call.from_user.id
    
    if data in NEKO_TAGS:
        image = requests.get(f"https://nekobot.xyz/api/image?type={data}").json()["message"]
        bot.send_photo(user_id, photo=image)
        
    if data in WAIFU_TAGS:
        res = requests.get(f"https://api.waifu.im/search?included_tags={data}").json()
        image = res["images"][0]["url"]
        bot.send_photo(user_id, photo=image)
        
    
if __name__ == "__main__":
    bot.infinity_polling()