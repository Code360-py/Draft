from telebot import TeleBot
from telebot.types import Message

class ClanCog:
    def __init__(self, bot: TeleBot):
        self.bot = bot
        self.register_handlers()

    def both(self, cmd):
        def decorator(func):
            self.bot.message_handler(commands=[cmd])(func)
            self.bot.channel_post_handler(commands=[cmd])(func)
            return func
        return decorator

    def register_handlers(self):
        @self.both("clancreate")
        def clancreate(message: Message):
            self.bot.send_message(message.chat.id, "🏰 Clan created (stub).")

        @self.both("claninfo")
        def claninfo(message: Message):
            self.bot.send_message(message.chat.id, "📜 Clan info (stub).")

def setup(bot: TeleBot):
    ClanCog(bot)