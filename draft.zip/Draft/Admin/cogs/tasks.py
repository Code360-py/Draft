from telebot import TeleBot
from telebot.types import Message

class TasksCog:
    def __init__(self, bot: TeleBot):
        self.bot = bot
        self.register_handlers()

    def both(self, cmd):
        def decorator(func):
            self.bot.message_handler(commands=[cmd])(func)
            self.bot.channel_post_handler(commands=[cmd])(func)
            return func
        return decorator

    def register_handlers(self):
        @self.both("taskadd")
        def taskadd(message: Message):
            self.bot.send_message(message.chat.id, "✅ Task added (stub).")

        @self.both("tasklist")
        def tasklist(message: Message):
            self.bot.send_message(message.chat.id, "📋 No tasks (stub).")

def setup(bot: TeleBot):
    TasksCog(bot)