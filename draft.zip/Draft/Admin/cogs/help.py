from telebot import TeleBot
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton, Message

CATEGORIES = {
    "basic": ["start", "hello", "ping", "botinfo", "userinfo", "channelinfo", "say"],
    "admin": ["shutdown", "load", "unload", "reload", "chatinfo", "broadcast", "dmall", "eval"],
    "economy": ["balance", "daily", "work", "pay", "leaderboard"],
    "analytics": ["stats", "topusers"],
    "clan": ["clancreate", "claninfo"],
    "jobs": ["jobs", "apply"],
    "tasks": ["taskadd", "tasklist"],
    "waifu": ["waifu", "hug"],
    "tools": ["weather", "translate"],
    "ytdlp": ["yt", "ytinfo"]
}

class HelpCog:
    def __init__(self, bot: TeleBot):
        self.bot = bot
        self.register_handlers()

    def register_handlers(self):
        @self.bot.message_handler(commands=["menu"], chat_types=["private"])
        def menu_private(message: Message):
            self.send_menu(message.chat.id)

        @self.bot.channel_post_handler(func=lambda m: m.text and m.text.strip().lower().startswith("#menu"))
        def menu_channel(message: Message):
            self.send_menu(message.chat.id)

        @self.bot.callback_query_handler(func=lambda call: call.data.startswith("help_cat_"))
        def on_category(call):
            cat = call.data.replace("help_cat_", "")
            cmds = CATEGORIES.get(cat, [])
            text = f"<b>{cat.title()} Commands</b>\n" + "\n".join(f"/{c}" for c in cmds)
            self.bot.answer_callback_query(call.id)
            self.bot.send_message(call.message.chat.id, text, parse_mode="HTML")

    def send_menu(self, chat_id: int):
        kb = InlineKeyboardMarkup()
        # row 1
        kb.row(
            InlineKeyboardButton("📦 Basic", callback_data="help_cat_basic"),
            InlineKeyboardButton("🛡 Admin", callback_data="help_cat_admin"),
            InlineKeyboardButton("💰 Economy", callback_data="help_cat_economy")
        )
        # row 2
        kb.row(
            InlineKeyboardButton("📊 Analytics", callback_data="help_cat_analytics"),
            InlineKeyboardButton("🏰 Clan", callback_data="help_cat_clan"),
            InlineKeyboardButton("💼 Jobs", callback_data="help_cat_jobs")
        )
        # row 3
        kb.row(
            InlineKeyboardButton("📅 Tasks", callback_data="help_cat_tasks"),
            InlineKeyboardButton("❤️ Waifu", callback_data="help_cat_waifu"),
            InlineKeyboardButton("🧰 Tools", callback_data="help_cat_tools")
        )
        kb.row(InlineKeyboardButton("📥 YTDLP", callback_data="help_cat_ytdlp"))

        self.bot.send_message(chat_id, "<b>📚 Help Menu</b>\nChoose a category:", reply_markup=kb, parse_mode="HTML")

def setup(bot: TeleBot):
    HelpCog(bot)