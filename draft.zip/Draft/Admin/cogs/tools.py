from telebot import TeleBot
from telebot.types import Message

class ToolsCog:
    def __init__(self, bot: TeleBot):
        self.bot = bot
        self.register_handlers()

    def both(self, cmd):
        def decorator(func):
            self.bot.message_handler(commands=[cmd])(func)
            self.bot.channel_post_handler(commands=[cmd])(func)
            return func
        return decorator

    def register_handlers(self):
        @self.both("weather")
        def weather(message: Message):
            self.bot.send_message(message.chat.id, "🌤 Weather feature not set up (stub).")

        @self.both("translate")
        def translate(message: Message):
            self.bot.send_message(message.chat.id, "🔤 Translate feature not set up (stub).")

def setup(bot: TeleBot):
    ToolsCog(bot)