from telebot import TeleBot
from telebot.types import Message
import json
import os

DATA = "data/economy.json"

def _ensure():
    if not os.path.exists("data"):
        os.makedirs("data")
    if not os.path.exists(DATA):
        with open(DATA, "w") as f:
            json.dump({}, f)

def _load():
    _ensure()
    with open(DATA, "r") as f:
        return json.load(f)

def _save(d):
    with open(DATA, "w") as f:
        json.dump(d, f, indent=2)

class EconomyCog:
    def __init__(self, bot: TeleBot):
        self.bot = bot
        _ensure()
        self.register_handlers()

    def both(self, cmd):
        def decorator(func):
            self.bot.message_handler(commands=[cmd])(func)
            self.bot.channel_post_handler(commands=[cmd])(func)
            return func
        return decorator

    def register_handlers(self):
        @self.both("balance")
        def balance(message: Message):
            data = _load()
            uid = str(message.from_user.id)
            bal = data.get(uid, {}).get("balance", 0)
            self.bot.send_message(message.chat.id, f"💰 Balance: <b>{bal}</b>", parse_mode="HTML")

        @self.both("daily")
        def daily(message: Message):
            data = _load()
            uid = str(message.from_user.id)
            user = data.setdefault(uid, {"balance": 0})
            user["balance"] = user.get("balance", 0) + 100
            _save(data)
            self.bot.send_message(message.chat.id, "🎉 You claimed daily 100 coins!", parse_mode="HTML")

        @self.both("pay")
        def pay(message: Message):
            parts = (message.text or "").split(maxsplit=2)
            if len(parts) < 3:
                return self.bot.reply_to(message, "❌ Usage: /pay <@username or user_id> <amount>")
            target = parts[1]
            try:
                amount = int(parts[2])
            except:
                return self.bot.reply_to(message, "❌ Amount must be a number.")
            # Simplified: assume user supplies user_id
            data = _load()
            payer = str(message.from_user.id)
            payee = target.lstrip("@")
            data.setdefault(payer, {"balance": 0})
            data.setdefault(payee, {"balance": 0})
            if data[payer]["balance"] < amount:
                return self.bot.reply_to(message, "❌ Not enough balance.")
            data[payer]["balance"] -= amount
            data[payee]["balance"] += amount
            _save(data)
            self.bot.send_message(message.chat.id, f"✅ Paid <b>{amount}</b> to {target}", parse_mode="HTML")

def setup(bot: TeleBot):
    EconomyCog(bot)