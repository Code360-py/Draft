from telebot import TeleBot
from telebot.types import Message

class WaifuCog:
    def __init__(self, bot: TeleBot):
        self.bot = bot
        self.register_handlers()

    def both(self, cmd):
        def decorator(func):
            self.bot.message_handler(commands=[cmd])(func)
            self.bot.channel_post_handler(commands=[cmd])(func)
            return func
        return decorator

    def register_handlers(self):
        @self.both("waifu")
        def waifu(message: Message):
            # Replace with API call or local images
            self.bot.send_message(message.chat.id, "🖼 Here is a waifu image (stub).")

        @self.both("hug")
        def hug(message: Message):
            self.bot.send_message(message.chat.id, "🤗 Hug sent (stub).")

def setup(bot: TeleBot):
    WaifuCog(bot)