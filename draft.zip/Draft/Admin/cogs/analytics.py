from telebot import TeleBot
from telebot.types import Message

class AnalyticsCog:
    def __init__(self, bot: TeleBot):
        self.bot = bot
        self.register_handlers()

    def both(self, cmd):
        def decorator(func):
            self.bot.message_handler(commands=[cmd])(func)
            self.bot.channel_post_handler(commands=[cmd])(func)
            return func
        return decorator

    def register_handlers(self):
        @self.both("stats")
        def stats(message: Message):
            self.bot.send_message(message.chat.id, "📊 Stats not implemented yet. Coming soon.")

        @self.both("topusers")
        def topusers(message: Message):
            self.bot.send_message(message.chat.id, "👥 Top users not implemented yet. Coming soon.")

def setup(bot: TeleBot):
    AnalyticsCog(bot)