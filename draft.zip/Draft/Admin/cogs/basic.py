from telebot import TeleBot
from telebot.types import Message

class BasicCog:
    def __init__(self, bot: TeleBot):
        self.bot = bot
        self.me = bot.get_me()
        self.register_handlers()

    def both(self, cmd):
        def decorator(func):
            self.bot.message_handler(commands=[cmd])(func)
            self.bot.channel_post_handler(commands=[cmd])(func)
            return func
        return decorator

    def register_handlers(self):
        @self.both("start")
        def start(message: Message):
            self.bot.send_message(message.chat.id, f"👋 Hello! I am {self.me.first_name}")

        @self.both("hello")
        def hello(message: Message):
            self.bot.send_message(message.chat.id, "👋 Hello everyone!")

        @self.both("ping")
        def ping(message: Message):
            self.bot.send_message(message.chat.id, "🏓 Pong! I am alive.")

        @self.both("botinfo")
        def botinfo(message: Message):
            txt = (
                "<b>🤖 Bot Information</b>\n"
                f"Name: <b>{self.me.first_name}</b>\n"
                f"Username: @{self.me.username}\n"
                f"ID: <code>{self.me.id}</code>"
            )
            self.bot.send_message(message.chat.id, txt, parse_mode="HTML")

        @self.both("say")
        def say(message: Message):
            text = (message.text or "").replace("/say", "", 1).strip()
            if not text:
                return self.bot.send_message(message.chat.id, "❌ Usage: /say <text>")
            self.bot.send_message(message.chat.id, text)

        @self.both("channelinfo")
        def channelinfo(message: Message):
            chat = message.chat
            txt = (
                "<b>📢 Channel/Chat Info</b>\n"
                f"Title: <b>{getattr(chat, 'title', 'Private/Unknown')}</b>\n"
                f"ID: <code>{chat.id}</code>\n"
                f"Type: <b>{chat.type}</b>"
            )
            self.bot.send_message(message.chat.id, txt, parse_mode="HTML")

def setup(bot: TeleBot):
    BasicCog(bot)