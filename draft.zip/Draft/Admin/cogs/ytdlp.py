from telebot import TeleBot
from telebot.types import Message

class YTDLPCog:
    def __init__(self, bot: TeleBot):
        self.bot = bot
        self.register_handlers()

    def both(self, cmd):
        def decorator(func):
            self.bot.message_handler(commands=[cmd])(func)
            self.bot.channel_post_handler(commands=[cmd])(func)
            return func
        return decorator

    def register_handlers(self):
        @self.both("yt")
        def yt(message: Message):
            parts = (message.text or "").split(maxsplit=1)
            if len(parts) < 2:
                return self.bot.reply_to(message, "❌ Usage: /yt <youtube_url>")
            url = parts[1]
            self.bot.send_message(message.chat.id, f"📥 Download stub for: {url}")

        @self.both("ytinfo")
        def ytinfo(message: Message):
            self.bot.send_message(message.chat.id, "ℹ yt info stub.")

def setup(bot: TeleBot):
    YTDLPCog(bot)