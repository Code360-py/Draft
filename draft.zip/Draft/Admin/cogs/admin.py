from telebot import TeleBot
from telebot.types import Message
import importlib
import sys
import os

OWNER_ID = 8322030170  # <-- set your Telegram ID

class AdminCog:
    def __init__(self, bot: TeleBot):
        self.bot = bot
        self.register_handlers()

    def is_owner(self, message: Message):
        return getattr(message.from_user, "id", None) == OWNER_ID

    def owner_block(self, message: Message):
        if not self.is_owner(message):
            self.bot.reply_to(message, "❌ Only the bot owner can use this command.")
            return False
        return True

    def register_handlers(self):
        @self.bot.message_handler(commands=["shutdown"])
        @self.bot.channel_post_handler(commands=["shutdown"])
        def shutdown(message: Message):
            if not self.owner_block(message): return
            self.bot.send_message(message.chat.id, "<b>⚠ Shutting down...</b>", parse_mode="HTML")
            sys.exit(0)

        @self.bot.message_handler(commands=["load"])
        def load_cog(message: Message):
            if not self.owner_block(message): return
            parts = (message.text or "").split(maxsplit=1)
            if len(parts) < 2:
                return self.bot.reply_to(message, "❌ Usage: /load <cog>")
            cog = parts[1]
            try:
                importlib.import_module(f"cogs.{cog}")
                self.bot.send_message(message.chat.id, f"✅ Loaded <b>{cog}</b>", parse_mode="HTML")
            except Exception as e:
                self.bot.send_message(message.chat.id, f"❌ Error loading {cog}\n<code>{e}</code>", parse_mode="HTML")

        @self.bot.message_handler(commands=["unload"])
        def unload_cog(message: Message):
            if not self.owner_block(message): return
            parts = (message.text or "").split(maxsplit=1)
            if len(parts) < 2:
                return self.bot.reply_to(message, "❌ Usage: /unload <cog>")
            cog = parts[1]
            try:
                del sys.modules[f"cogs.{cog}"]
                self.bot.send_message(message.chat.id, f"🗑 Unloaded <b>{cog}</b>", parse_mode="HTML")
            except Exception as e:
                self.bot.send_message(message.chat.id, f"❌ Error unloading {cog}\n<code>{e}</code>", parse_mode="HTML")

        @self.bot.message_handler(commands=["reload"])
        def reload_cog(message: Message):
            if not self.owner_block(message): return
            parts = (message.text or "").split(maxsplit=1)
            if len(parts) < 2:
                return self.bot.reply_to(message, "❌ Usage: /reload <cog>")
            cog = parts[1]
            try:
                importlib.reload(importlib.import_module(f"cogs.{cog}"))
                self.bot.send_message(message.chat.id, f"🔄 Reloaded <b>{cog}</b>", parse_mode="HTML")
            except Exception as e:
                self.bot.send_message(message.chat.id, f"❌ Error reloading {cog}\n<code>{e}</code>", parse_mode="HTML")

        @self.bot.message_handler(commands=["chatinfo"])
        def chatinfo(message: Message):
            chat = message.chat
            txt = (
                "<b>📌 Chat Information</b>\n"
                f"Name: <b>{getattr(chat, 'title', 'Private/Unknown')}</b>\n"
                f"Chat ID: <code>{chat.id}</code>\n"
                f"Type: <b>{chat.type}</b>"
            )
            self.bot.send_message(message.chat.id, txt, parse_mode="HTML")

        @self.bot.message_handler(commands=["broadcast"])
        def broadcast(message: Message):
            if not self.owner_block(message): return
            parts = (message.text or "").split(maxsplit=1)
            if len(parts) < 2:
                return self.bot.reply_to(message, "❌ Usage: /broadcast <message>")
            msg = parts[1]
            if not os.path.exists("chats.txt"):
                return self.bot.reply_to(message, "⚠ No chats logged.")
            count = 0
            for cid in open("chats.txt").read().splitlines():
                try:
                    self.bot.send_message(cid, msg)
                    count += 1
                except:
                    pass
            self.bot.send_message(message.chat.id, f"📢 Broadcast sent to <b>{count}</b> chats.", parse_mode="HTML")

        @self.bot.message_handler(commands=["dmall"])
        def dmall(message: Message):
            if not self.owner_block(message): return
            parts = (message.text or "").split(maxsplit=1)
            if len(parts) < 2:
                return self.bot.reply_to(message, "❌ Usage: /dmall <message>")
            msg = parts[1]
            if not os.path.exists("users.txt"):
                return self.bot.reply_to(message, "⚠ No users logged.")
            count = 0
            for uid in open("users.txt").read().splitlines():
                try:
                    self.bot.send_message(uid, msg)
                    count += 1
                except:
                    pass
            self.bot.send_message(message.chat.id, f"📨 DM sent to <b>{count}</b> users.", parse_mode="HTML")

        @self.bot.message_handler(commands=["eval"])
        def eval_code(message: Message):
            if not self.owner_block(message): return
            parts = (message.text or "").split(maxsplit=1)
            if len(parts) < 2:
                return self.bot.reply_to(message, "❌ Usage: /eval <python code>")
            code = parts[1]
            try:
                result = eval(code)
                self.bot.send_message(message.chat.id, f"🧪 <b>Result:</b>\n<code>{result}</code>", parse_mode="HTML")
            except Exception as e:
                self.bot.send_message(message.chat.id, f"❌ Error:\n<code>{e}</code>", parse_mode="HTML")

def setup(bot: TeleBot):
    AdminCog(bot)