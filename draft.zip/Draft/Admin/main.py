from telebot import TeleBot
from telebot.types import BotCommand
from utils.loader import load_cogs

TOKEN = "7987858288:AAEFV0Nqh8nuGW4dkzsISq9FMtDbjwCIIEA"
bot = TeleBot(TOKEN, parse_mode="HTML")

# ---------- BotFather "slash" menu (Option A) ----------
def register_botfather_commands(bot):
    commands = [
        # Basic
        BotCommand("start", "Start the bot"),
        BotCommand("hello", "Say hello"),
        BotCommand("ping", "Check bot status"),
        BotCommand("botinfo", "Get bot info"),
        BotCommand("userinfo", "Get your info"),
        BotCommand("channelinfo", "Get channel info"),
        BotCommand("say", "Make the bot say something"),
        BotCommand("menu", "Open inline menu"),

        # Admin
        BotCommand("shutdown", "Turn off the bot (owner)"),
        BotCommand("load", "Load a cog (owner)"),
        BotCommand("unload", "Unload a cog (owner)"),
        BotCommand("reload", "Reload a cog (owner)"),
        BotCommand("chatinfo", "Chat info (owner)"),
        BotCommand("broadcast", "Broadcast to saved chats (owner)"),
        BotCommand("dmall", "DM saved users (owner)"),
        BotCommand("eval", "Evaluate python (owner)"),

        # Economy (examples)
        BotCommand("balance", "Check your balance"),
        BotCommand("daily", "Claim daily reward"),
        BotCommand("work", "Work to earn coins"),
        BotCommand("pay", "Pay another user"),
        BotCommand("leaderboard", "Show rich users"),

        # Analytics
        BotCommand("stats", "Show channel stats"),
        BotCommand("topusers", "Top active users"),

        # Clan
        BotCommand("clancreate", "Create a clan"),
        BotCommand("claninfo", "Clan info"),

        # Jobs
        BotCommand("jobs", "List jobs"),
        BotCommand("apply", "Apply for a job"),

        # Tasks
        BotCommand("taskadd", "Add a task"),
        BotCommand("tasklist", "List tasks"),

        # Waifu / Tools / YT
        BotCommand("waifu", "Send random waifu image"),
        BotCommand("weather", "Get weather report"),
        BotCommand("yt", "Download YouTube video (yt-dlp)"),
    ]
    bot.set_my_commands(commands)

# ---------- Load cogs ----------
register_botfather_commands(bot)
load_cogs(bot)

print("Bot is running...")
bot.infinity_polling()