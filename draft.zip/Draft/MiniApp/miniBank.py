import sqlite3, hashlib, getpass
import os, random, string
import datetime, sys
from typing import Optional

DB_FILE = "bank.db"

def hash_text(text: str) -> str:
    return hashlib.sha256(text.encode()).hexdigest()
    
def generate_txn_id() -> str:
    ts = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
    rand = ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))
    return f"TXN-{ts}-{rand}"
    
def clear_console():
    os.system('cls' if os.name == 'nt' else 'clear')

def safe_float_input(prompt: str) -> Optional[float]:
    val = input(prompt).strip()
    try:
        f = float(val)
        return f
    except ValueError:
        print("⚠️ Invalid number.")
        return None
        
        
class BankDB:
    def __init__(self, db_name: str = DB_FILE):
        self.conn = sqlite3.connect(db_name)
        self.cursor = self.conn.cursor()
        self.setup()

    def setup(self):
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                username TEXT PRIMARY KEY,
                password_hash TEXT NOT NULL,
                pin_hash TEXT NOT NULL,
                balance REAL DEFAULT 0,
                is_admin INTEGER DEFAULT 0
            )
        """)
        
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT,
                txn_id TEXT,
                type TEXT,
                amount REAL,
                balance_after REAL,
                timestamp TEXT
            )
        """)
        self.conn.commit()
        self._ensure_admin()

    def _ensure_admin(self):
        self.cursor.execute("SELECT COUNT(*) FROM users WHERE is_admin=1")
        count = self.cursor.fetchone()[0]
        if count == 0:
            default_admin = "admin"
            default_pass = "admin123"
            default_pin = "0000"
            self.create_user(default_admin, hash_text(default_pass), hash_text(default_pin), is_admin=1)
            print(f"[setup] default admin created -> username: '{default_admin}' password: '{default_pass}' (change ASAP)")
            
    def create_user(self, username: str, password_hash: str, pin_hash: str, is_admin: int = 0) -> bool:
        try:
            self.cursor.execute(
                "INSERT INTO users (username, password_hash, pin_hash, balance, is_admin) VALUES (?, ?, ?, ?, ?)",
                (username, password_hash, pin_hash, 0.0, is_admin)
            )
            self.conn.commit()
            return True
        except sqlite3.IntegrityError:
            return False

    def get_user(self, username: str):
        self.cursor.execute("SELECT username, password_hash, pin_hash, balance, is_admin FROM users WHERE username=?", (username,))
        return self.cursor.fetchone()

    def update_balance(self, username: str, new_balance: float):
        self.cursor.execute("UPDATE users SET balance=? WHERE username=?", (new_balance, username))
        self.conn.commit()

    def delete_user(self, username: str):
        self.cursor.execute("DELETE FROM users WHERE username=?", (username,))
        self.cursor.execute("DELETE FROM transactions WHERE username=?", (username,))
        self.conn.commit()

    def list_users(self):
        self.cursor.execute("SELECT username, balance, is_admin FROM users")
        return self.cursor.fetchall()
        
    def add_transaction(self, username: str, txn_type: str, amount: float, balance_after: Optional[float]) -> str:
        txn_id = generate_txn_id()
        ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.cursor.execute("""
            INSERT INTO transactions (username, txn_id, type, amount, balance_after, timestamp)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (username, txn_id, txn_type, amount, balance_after, ts))
        self.conn.commit()
        return txn_id

    def get_transactions_for_user(self, username: str, limit: int = 100):
        self.cursor.execute("""
            SELECT txn_id, type, amount, balance_after, timestamp
            FROM transactions
            WHERE username=?
            ORDER BY id DESC
            LIMIT ?
        """, (username, limit))
        return self.cursor.fetchall()

    def list_all_transactions(self, limit: int = 500):
        self.cursor.execute("""
            SELECT id, username, txn_id, type, amount, balance_after, timestamp
            FROM transactions
            ORDER BY id DESC
            LIMIT ?
        """, (limit,))
        return self.cursor.fetchall()


class BankAccount:
    def __init__(self, username: str, password_hash: str, pin_hash: str, balance: float, is_admin: int, db: BankDB):
        self.username = username
        self.password_hash = password_hash
        self.pin_hash = pin_hash
        self.balance = float(balance)
        self.is_admin = bool(is_admin)
        self.db = db

    def verify_password(self, pwd: str) -> bool:
        return hash_text(pwd) == self.password_hash

    def verify_pin(self, pin: str) -> bool:
        return hash_text(pin) == self.pin_hash

    def deposit(self, amt: float):
        if amt <= 0:
            print("⚠️ Deposit amount must be positive.")
            return
        self.balance += amt
        self.db.update_balance(self.username, self.balance)
        txn = self.db.add_transaction(self.username, "DEPOSIT", amt, self.balance)
        print(f"💸 Deposited {amt:.2f}. TXN: {txn} | New balance: {self.balance:.2f}")

    def withdraw(self, amt: float):
        if amt <= 0:
            print("⚠️ Withdraw amount must be positive.")
            return
        if amt > self.balance:
            print("❌ Insufficient funds.")
            return
        self.balance -= amt
        self.db.update_balance(self.username, self.balance)
        txn = self.db.add_transaction(self.username, "WITHDRAW", amt, self.balance)
        print(f"💵 Withdrawn {amt:.2f}. TXN: {txn} | New balance: {self.balance:.2f}")

    def transfer(self, to_username: str, amt: float):
        if to_username == self.username:
            print("⚠️ Cannot transfer to yourself.")
            return
        if amt <= 0:
            print("⚠️ Transfer amount must be positive.")
            return
        if amt > self.balance:
            print("❌ Not enough balance.")
            return
        # check recipient exists
        tgt = self.db.get_user(to_username)
        if not tgt:
            print("❌ Recipient not found.")
            return
        
        self.balance -= amt
        self.db.update_balance(self.username, self.balance)
        txn_out = self.db.add_transaction(self.username, "TRANSFER_OUT", amt, self.balance)
        
        new_receiver_balance = float(tgt[3]) + amt
        self.db.update_balance(to_username, new_receiver_balance)
        txn_in = self.db.add_transaction(to_username, "TRANSFER_IN", amt, new_receiver_balance)
        print(f"📤 Sent {amt:.2f} to {to_username}. TXN_OUT: {txn_out} | TXN_IN: {txn_in}")
        print(f"Your new balance: {self.balance:.2f}")

    def show_balance(self):
        print(f"💰 Balance for {self.username}: {self.balance:.2f}")

    def get_history(self, limit: int = 100):
        rows = self.db.get_transactions_for_user(self.username, limit=limit)
        return rows


def show_history(username: str, db: BankDB, limit: int = 100):
    rows = db.get_transactions_for_user(username, limit=limit)
    print("\n=== 📜 TRANSACTION HISTORY ===")
    if not rows:
        print("No transactions yet.")
        return
    print("TXN_ID | TYPE | AMOUNT | BAL_AFTER | TIMESTAMP")
    for r in rows:
        txn_id, ttype, amt, bal_after, ts = r
        bal_after_str = f"{bal_after:.2f}" if bal_after is not None else "N/A"
        print(f"{txn_id} | {ttype} | {amt:.2f} | {bal_after_str} | {ts}")


def atm_ui(acc: BankAccount):
    while True:
        print("\n==============================")
        print(f"   💳 ATM PANEL — {acc.username}")
        print("==============================")
        print("| 1. Withdraw    2. Deposit  |")
        print("| 3. Balance     4. History  |")
        print("| 5. Transfer    6. Logout   |")
        print("==============================")
        choice = input("👉 Choose: ").strip()

        if choice == "1":
            amt = safe_float_input("Withdraw amount: ")
            if amt is not None:
                acc.withdraw(amt)

        elif choice == "2":
            amt = safe_float_input("Deposit amount: ")
            if amt is not None:
                acc.deposit(amt)

        elif choice == "3":
            acc.show_balance()

        elif choice == "4":
            show_history(acc.username, acc.db)

        elif choice == "5":
            to_user = input("Recipient username: ").strip()
            amt = safe_float_input("Amount: ")
            if amt is not None:
                acc.transfer(to_user, amt)

        elif choice == "6":
            print("👋 Logged out!")
            break

        else:
            print("⚠️ Invalid choice - try again.")


def admin_menu(acc: BankAccount):
    db = acc.db
    while True:
        print("\n===== 🛠 ADMIN PANEL =====")
        print("1. View Users")
        print("2. View Recent Transactions")
        print("3. View User Transactions")
        print("4. Delete User")
        print("5. Reset User PIN/Password")
        print("6. Logout Admin")
        choice = input("👉 Choose: ").strip()

        if choice == "1":
            rows = db.list_users()
            print("\nusername | balance | is_admin")
            for u in rows:
                print(f"{u[0]} | {u[1]:.2f} | {u[2]}")

        elif choice == "2":
            rows = db.list_all_transactions(limit=200)
            print("\nid | username | txn_id | type | amt | bal_after | ts")
            for r in rows:
                print(r)

        elif choice == "3":
            target = input("Enter username to view history: ").strip()
            show_history(target, db)

        elif choice == "4":
            target = input("Enter username to delete: ").strip()
            confirm = input(f"Type DELETE to remove '{target}': ")
            if confirm == "DELETE":
                db.delete_user(target)
                print("User and their transactions deleted.")
            else:
                print("Aborted.")

        elif choice == "5":
            target = input("Enter username to reset: ").strip()
            user = db.get_user(target)
            if not user:
                print("User not found.")
                continue
            new_pass = getpass.getpass("New password: ")
            new_pass2 = getpass.getpass("Confirm password: ")
            if new_pass != new_pass2:
                print("Passwords don't match.")
                continue
            new_pin = getpass.getpass("New 4-digit PIN: ")
            if not (new_pin.isdigit() and len(new_pin) == 4):
                print("PIN must be 4 digits.")
                continue
            db.cursor.execute("UPDATE users SET password_hash=?, pin_hash=? WHERE username=?",
                              (hash_text(new_pass), hash_text(new_pin), target))
            db.conn.commit()
            print("Reset done.")

        elif choice == "6":
            break

        else:
            print("⚠️ Invalid option.")


def create_account_flow(db: BankDB):
    print("\n=== Create Account ===")
    username = input("Choose a username: ").strip()
    if not username:
        print("Username cannot be empty.")
        return
    if db.get_user(username):
        print("Username already exists.")
        return
    password = getpass.getpass("Create password: ")
    confirm = getpass.getpass("Confirm password: ")
    if password != confirm:
        print("Passwords do not match.")
        return
    pin = getpass.getpass("Set 4-digit PIN: ")
    if not (pin.isdigit() and len(pin) == 4):
        print("PIN must be exactly 4 digits.")
        return
    ok = db.create_user(username, hash_text(password), hash_text(pin), is_admin=0)
    if ok:
        print("🎉 Account created.")
    else:
        print("❌ Failed to create account.")


def login_flow(db: BankDB) -> Optional[BankAccount]:
    print("\n=== Login ===")
    username = input("Username: ").strip()
    if not username:
        print("Invalid username.")
        return None
    user = db.get_user(username)
    if not user:
        print("User not found.")
        return None
    password = getpass.getpass("Password: ")
    if hash_text(password) != user[1]:
        print("❌ Wrong password.")
        return None
    pin = getpass.getpass("Enter 4-digit PIN: ")
    if hash_text(pin) != user[2]:
        print("❌ Wrong PIN.")
        return None
    print("✔️ Login successful.")
    return BankAccount(user[0], user[1], user[2], user[3], user[4], db)


def main_menu():
    db = BankDB()
    while True:
        print("\n====== 🏦 GenZ Secure ATM ======")
        print("1. Create Account")
        print("2. Login")
        print("3. Exit")
        print("===============================")
        choice = input("👉 Pick an option: ").strip()
        if choice == "1":
            create_account_flow(db)
        elif choice == "2":
            account = login_flow(db)
            if account:
                if account.is_admin:
                    admin_menu(account)
                else:
                    atm_ui(account)
        elif choice == "3":
            print("👋 Peace out!")
            sys.exit(0)
        else:
            print("⚠️ Invalid choice.")


if __name__ == "__main__":
    try:
        main_menu()
    except KeyboardInterrupt:
        print("\n👋 Exiting. Stay safe.")
        sys.exit(0)