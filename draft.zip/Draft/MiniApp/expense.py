import json
import os
import hashlib
import getpass
from datetime import datetime

# -------------------------
# Colored output
# -------------------------
class Color:
    BLUE = "\033[94m"
    GREEN = "\033[92m"
    RED = "\033[91m"
    CYAN = "\033[96m"
    YELLOW = "\033[93m"
    MAGENTA = "\033[95m"
    RESET = "\033[0m"
    BOLD = "\033[1m"

# -------------------------
# Utility functions
# -------------------------
def hash_password(password: str):
    return hashlib.sha256(password.encode()).hexdigest()

def get_timestamp():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

# -------------------------
# Expense Tracker App
# -------------------------
class ExpenseTracker:
    def __init__(self, file="users.json"):
        self.file = file
        self.users = {}
        self.current_user = None
        self.load_users()

    # -------------------------
    # File Operations
    # -------------------------
    def load_users(self):
        if os.path.exists(self.file):
            try:
                with open(self.file, "r") as f:
                    self.users = json.load(f)
            except:
                self.users = {}
        else:
            self.users = {}

    def save_users(self):
        with open(self.file, "w") as f:
            json.dump(self.users, f, indent=4)

    # -------------------------
    # User Management
    # -------------------------
    def create_user(self, username, password):
        if username in self.users:
            print(f"{Color.YELLOW}Username already exists!{Color.RESET}")
            return False
        self.users[username] = {"password": hash_password(password), "expenses": []}
        self.save_users()
        print(f"{Color.GREEN}User '{username}' created successfully!{Color.RESET}")
        return True

    def login_user(self, username, password):
        if username not in self.users:
            print(f"{Color.RED}Username not found!{Color.RESET}")
            return False
        if self.users[username]["password"] != hash_password(password):
            print(f"{Color.RED}Incorrect password!{Color.RESET}")
            return False
        self.current_user = username
        print(f"{Color.GREEN}Login successful! Welcome, {username}.{Color.RESET}")
        return True

    def logout_user(self):
        if self.current_user:
            print(f"{Color.YELLOW}User '{self.current_user}' logged out.{Color.RESET}")
            self.current_user = None
        else:
            print(f"{Color.RED}No user is logged in.{Color.RESET}")

    # -------------------------
    # Expense Management
    # -------------------------
    def add_expense(self, amount, category, description=""):
        if not self.current_user:
            print(f"{Color.RED}Please login first!{Color.RESET}")
            return
        expense = {
            "amount": float(amount),
            "category": category,
            "description": description,
            "date": get_timestamp()
        }
        self.users[self.current_user]["expenses"].append(expense)
        self.save_users()
        print(f"{Color.GREEN}Expense added successfully!{Color.RESET}")

    def view_expenses(self):
        if not self.current_user:
            print(f"{Color.RED}Please login first!{Color.RESET}")
            return
        expenses = self.users[self.current_user]["expenses"]
        if expenses:
            print(f"\n{Color.BOLD}{Color.CYAN}--- {self.current_user}'s Expenses ---{Color.RESET}")
            total = 0
            for i, e in enumerate(expenses, 1):
                total += e["amount"]
                print(f"{i}. {e['category']} → {e['amount']} | {e['description']} | Date: {e['date']}")
            print(f"{Color.BOLD}{Color.GREEN}Total Expenses: {total}{Color.RESET}\n")
        else:
            print(f"{Color.RED}No expenses found.{Color.RESET}")

    def search_expenses(self, keyword):
        if not self.current_user:
            print(f"{Color.RED}Please login first!{Color.RESET}")
            return
        expenses = [e for e in self.users[self.current_user]["expenses"] if keyword.lower() in e["category"].lower() or keyword.lower() in e["description"].lower()]
        if expenses:
            print(f"\n{Color.BOLD}{Color.CYAN}--- Search Results ---{Color.RESET}")
            total = 0
            for i, e in enumerate(expenses, 1):
                total += e["amount"]
                print(f"{i}. {e['category']} → {e['amount']} | {e['description']} | Date: {e['date']}")
            print(f"{Color.BOLD}{Color.GREEN}Total: {total}{Color.RESET}\n")
        else:
            print(f"{Color.RED}No expenses found for '{keyword}'.{Color.RESET}")

    def delete_expense(self, index):
        if not self.current_user:
            print(f"{Color.RED}Please login first!{Color.RESET}")
            return
        expenses = self.users[self.current_user]["expenses"]
        if 0 <= index - 1 < len(expenses):
            removed = expenses.pop(index - 1)
            self.save_users()
            print(f"{Color.RED}Deleted expense: {removed['category']} → {removed['amount']}{Color.RESET}")
        else:
            print(f"{Color.RED}Invalid Expense ID!{Color.RESET}")

    # -------------------------
    # Menu
    # -------------------------
    def show_main_menu(self):
        if not self.current_user:
            print(f"""
{Color.BOLD}{Color.BLUE}=========== PERSONAL EXPENSE TRACKER ==========={Color.RESET}
1. Create User
2. Login
3. Exit
{Color.BLUE}===============================================\n{Color.RESET}
""")
        else:
            print(f"""
{Color.BOLD}{Color.BLUE}=========== PERSONAL EXPENSE TRACKER ==========={Color.RESET}
1. View My Expenses
2. Add Expense
3. Delete Expense
4. Search Expenses
5. Logout
{Color.BLUE}===============================================\n{Color.RESET}
""")

    # -------------------------
    # Main Loop
    # -------------------------
    def main(self):
        print(f"{Color.GREEN}{Color.BOLD}Welcome to the Personal Expense Tracker!{Color.RESET}")

        while True:
            self.show_main_menu()
            choice = input(f"{Color.CYAN}Enter an option: {Color.RESET}")

            if not self.current_user:
                if choice == "1":
                    username = input("Enter new username: ")
                    password = getpass.getpass("Set password: ")
                    self.create_user(username, password)
                elif choice == "2":
                    username = input("Enter username: ")
                    password = getpass.getpass("Enter password: ")
                    self.login_user(username, password)
                elif choice == "3":
                    print(f"{Color.YELLOW}Goodbye!{Color.RESET}")
                    break
                else:
                    print(f"{Color.RED}Invalid option. Please login or create an account.{Color.RESET}")

            else:
                if choice == "1":
                    self.view_expenses()
                elif choice == "2":
                    amount = input("Amount: ")
                    category = input("Category (Food, Travel, Bills, etc.): ")
                    description = input("Description (optional): ")
                    self.add_expense(amount, category, description)
                elif choice == "3":
                    try:
                        idx = int(input("Enter Expense ID to delete: "))
                        self.delete_expense(idx)
                    except:
                        print(f"{Color.RED}Invalid input.{Color.RESET}")
                elif choice == "4":
                    keyword = input("Keyword to search: ")
                    self.search_expenses(keyword)
                elif choice == "5":
                    self.logout_user()
                else:
                    print(f"{Color.RED}Invalid option. Choose from the menu.{Color.RESET}")

# -------------------------
# Run App
# -------------------------
if __name__ == '__main__':
    ExpenseTracker().main()